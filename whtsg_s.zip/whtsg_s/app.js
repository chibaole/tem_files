/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-06-03 16:56:57
 * @Description: file content
 */
const Koa = require('koa')
const {
  resolve
} = require('path')
const serve = require('koa-static')
const Router = require('koa-router')
const config = require('./config/config')
const koaBody = require('koa-body');
const {
  initSchemas,
  connect
} = require('./app/database/init')
var cors = require('koa2-cors');;
(async () => {

  await connect(config.db)
  initSchemas()

  

  // 生成服务器实例
  const app = new Koa()
  const router = new Router()

  app.keys = ['wechat_server']

  app.use(serve(resolve(__dirname, './public')))
  app.use(cors());

  var path = require('path');

  app.use(koaBody({
    // 支持文件格式
    multipart: true,

  }));

  require('./router/index')(router)

  app.use(router.routes()).use(router.allowedMethods())
  app.listen(config.port)
  console.log('Listen: ' + config.port)
})()