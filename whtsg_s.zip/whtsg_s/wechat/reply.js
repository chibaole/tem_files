/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:40:03
 * @Description: file content
 */
const {
  resolve
} = require('path')
const api = require('../app/api/index')

const help = '亲 欢迎关注武汉大学图书馆 \n' +
  '回复 1，测试文字回复\n' 
exports.reply = async (ctx, next) => {
  const message = ctx.weixin
  let mp = require('./index')
  let client = mp.getWechat()
  let reply = ''
  // 事件消息
  if (message.MsgType === 'event') {
    if (message.Event === 'subscribe') {
      // 关注事件
      let openid = message.FromUserName
      const WdBoyData = await api.elib.saveWdBoy(message)
      reply = help
    } else if (message.Event === 'unsubscribe') {
      await api.elib.delWdBoy(message)
      reply = '您已取消订阅'
    } else if (message.Event === 'VIEW') {
      reply = `你点击了菜单链接:${message.EventKey}`
    } else if (message.Event === 'location_select') {
    } else if (message.Event === 'LOCATION') {
      //签到逻辑？
      
    } else if (message.Event === 'CLICK') {
      // 菜单点击事件
      let click_value = message.EventKey //
      if(click_value =='bz_zn'){
         //获图文信息列表
         let options = {
          type:'news',
          offset:0,
          count:20
        }
        let tw_list =    await client.handle('batchMaterial', options)
        let cur_media_id = ``
        for(let i = 0;i<tw_list.item.length;i++){
          if(tw_list.item[i].content.news_item[0].title.indexOf('全面免押金借书服务') !=-1){
            cur_media_id = tw_list.item[i].media_id
          }
        }
        let newsData = await client.handle('fetchMaterial', cur_media_id, 'news', true)
        let items = newsData.news_item
        let news = []
        let data2 = await client.handle('uploadMaterial', 'pic', resolve(__dirname, '../qylog.jpg'), {
          type: 'image'
        })
    
        items.forEach(item => {
          news.push({
            title: item.title,
            description: item.description,
            picUrl: data2.url,
            url: item.url
          })
        })
        reply =news
      }else if(click_value =='bg_js'){
        //获图文信息列表
        let options = {
          type:'news',
          offset:0,
          count:20
        }
        let tw_list =    await client.handle('batchMaterial', options)
        let cur_media_id = ``
        for(let i = 0;i<tw_list.item.length;i++){
          if(tw_list.item[i].content.news_item[0].title.indexOf('清远市图书管简介') !=-1){
            cur_media_id = tw_list.item[i].media_id
          }
        }
        // 
        let newsData = await client.handle('fetchMaterial', cur_media_id, 'news', true)
        let items = newsData.news_item
        let news = []
        let data2 = await client.handle('uploadMaterial', 'pic', resolve(__dirname, '../lpp.jpg'), {
          type: 'image'
        })
        items.forEach(item => {
          news.push({
            title: item.title,
            description: item.description,
            picUrl: data2.url,
            url: item.url
          })
        })
        reply =news
      }else if(click_value =='wd_fb'){
        reply = `数据正在爬取整理`
      }else{
        reply = `菜单点击 的Key为：${click_value}`
      }
    }
    ctx.body = reply
  } else if (message.MsgType === 'text') {
    let content = message.Content
    if (content === '2') {
      reply = `菜单已更新`
    }
    ctx.body = reply
  } else if (message.MsgType === 'voice') {
    let content = message.Recognition //语音内容
    let reply = '没有查询到与 ' + content + ' 相关的图书，要不要换一个名字试试看哦！'
    if (content.indexOf('1234') != -1) {
      let openid = message.FromUserName
      let param = {
        openid: openid
      }
      let res = await api.elib.yyRenewFn(param)
      let successBook = ''
      let failBook = ''
      for (let i = 0; i < res.length; i++) {
        if (res[i].status === '9999') {
          failBook = failBook + '-《' + res[i].title + '》-'
        } else {
          successBook = successBook + '-《' + res[i].title + '》-'
        }
      }

      if (successBook) {
        reply = `${successBook} 成功续借`
      } else {
        reply = `${failBook}不可续借 没有其他可续借的图书`
      }

    } else {
      let reply = '您说的' + content + ' 没有 <续借> 关键词 无法完成续借操作'
    }
    ctx.body = reply
  }
  await next()
}