/*
 * @Author: 刘攀
 * @Date: 2020-03-12 14:07:54
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-04-17 16:28:29
 * @Description: file content
 */
const mongoose = require('mongoose')
const Schema = mongoose.Schema
const QuestionsSchema = new Schema({
    cid: String,
    type: String,
    title: String,
    items:Array,
    answer:Array,

    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

QuestionsSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = this.meta.updatedAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})
QuestionsSchema.statics = {
    async setitem(data) {
        let question  = await this.findOne({
            "cid": data.cid
        })
        if(question){
            question.type = data.type
            question.title = data.title
            question.items = data.items
            question.answer = data.answer
        }else{

            question = new Questions({
                cid: data.cid,
                type: data.type,
                title: data.title,
                items: data.items,
                answer: data.answer
            })
        }
        await question.save()
        return question
    },
    async getAllQuestion(param){
        console.log(param)
        let size = Number(param.limit)
        let questions = await this.aggregate( [ { $sample: { size: size } },{$project: {
		    cid: 1,type:1,title:1,items:1}} ] )
        if (questions) {
            return questions
        } else {
            return {
                msg: '题库不全'
            }
        }
    },
    async getAnswer(){
        // db.news.find( {}, { id: 1, title: 1 } )

        let res = await this.find({},{cid:1,answer:1})
        return res
    }

}


const Questions = mongoose.model('Questions', QuestionsSchema)