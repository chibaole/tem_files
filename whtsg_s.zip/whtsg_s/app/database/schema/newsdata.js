// 爬取图书馆公告的数据
/*
 * @Author: 刘攀
 * @Date: 2019-11-26 16:46:24
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-03-04 17:15:20
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const NewsDataSchema = new Schema({
    type: String,
    title: String,
    link: String,
    time: Date,
    name: String,
    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

NewsDataSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

NewsDataSchema.statics = {
    async getFirstOne() {
        // let newData = await this.find().sort({
        //     _id: 1
        // }).limit(1)
        let newData = null
        try {
            newData = await this.find({
                "name": "爬虫数据"
            }).sort({
                time: -1
            }).limit(1)
            // console.log(newData)
            return newData
        } catch (error) {
            console.log(error)
            return false
        }
    },
    async getlastOne() {
        let lastone = await this.find().skip(this.count() - 1)
        return lastone
    },
    async getNewsData(param) {
        let last_id = param.last_id
        let newsdata = null
        last_id == 'init' ? newsdata = await this.find().sort({
            _id: 1
        }).limit(10) : newsdata = await this.find({
            _id: {
                $gt: last_id
            }
        }).sort({
            _id: 1
        }).limit(10)

        if (newsdata) {
            return newsdata
        } else {
            return {
                status: false
            }
        }

    },

    async setNewsData(data) {

        let newsdata = await this.findOne({
            'link': data.link
        })
        if (!newsdata) {
            console.log('插入数据')
            let news = new NewsData({
                name: '爬虫数据',
                type: data.type,
                title: data.title,
                link: data.link,
                time: new Date(data.time)
            })
            await news.save()
            return news
        }

        try {
            if (!newsdata) {
                console.log('插入数据')
                let news = new NewsData({
                    name: '爬虫数据',
                    type: data.type,
                    title: data.title,
                    link: data.link,
                    time: new Date(data.time)
                })
                await news.save()
                return news
            }
        } catch (error) {
            console.log(error)
        }

    },
    async delNewsData(param) {

        let res = await this.remove({}, function (err) {
            return err
        });
        return res

    },
    async testData() {
        let res = await await this.deleteMany()
        return res
    },
    async getNewForTime(param) {
        let last_time = param.last_time
        console.log(last_time)
        let news = null
        //默认返回最近10条信息
        if (last_time == 'init') {
            let news_list1 = await this.find({
                "name": "爬虫数据"
            }).sort({
                time: -1
            }).limit(15)
            news = news_list1
            return news
        } else {
            //根据传入的日期时间 查询 后10条
            news = await this.find({
                time: {
                    $lt: new Date(last_time)
                }
            }).limit(15)
        }
        return news
    }
}

const NewsData = mongoose.model('NewsData', NewsDataSchema)