/*
 * @Author: 刘攀
 * @Date: 2020-03-18 15:45:10
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-03-18 16:07:33
 * @Description: file content
 */
const mongoose = require('mongoose')
const Schema = mongoose.Schema
const IntroSchema = new Schema({
  
    intro_data: Object,

    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

IntroSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

IntroSchema.statics = {
    async getOne(param) {

        let intro = null
        try {
            intro = await this.findOne({
            },{intro_data:1})

            return intro

        } catch (error) {
            console.log(error)
            return false
        }
    },
    async setOne(param) {

        console.log(typeof param)
        try {
            let intro = null
            intro = await this.findOne({})
            if (!intro) {
                console.log('上传活动介绍')
                let intro_info = new Intro({
                    intro_data:param.page_data
                })
                await intro_info.save()
                return intro_info
            }else{
                return{
                    msg:'已存在活动介绍'
                }
            }
        } catch (error) {
            console.log(error)
        }

    },

 
 
}

const Intro= mongoose.model('Intro', IntroSchema)