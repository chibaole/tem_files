/*
 * @Author: 刘攀
 * @Date: 2020-03-11 15:39:07
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-03-17 16:16:14
 * @Description: file content
 */
const mongoose = require('mongoose')
const Schema = mongoose.Schema
const AnswerManSchema = new Schema({
    name: String,
    mobile: String,
    vcode: String,
    scores: String,
    result: Object,
    isJoin:Boolean,
    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

AnswerManSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

AnswerManSchema.statics = {
    async getOne(param) {
        let mobile = param.mobile

        let answerman = null
        try {
            answerman = await this.findOne({
                "mobile": mobile
            })

            return answerman

        } catch (error) {
            console.log(error)
            return false
        }
    },
    async setOne(param) {


        try {
            let answerman = null
            answerman = await this.findOne({
                "mobile": param.mobile
            })
            if (!answerman) {
                console.log('新参加的用户')
                let people_info = new AnswerMan({
                    name: param.name || '',
                    mobile: param.mobile || '',
                    vcode: param.vcode || '',
                    scores: param.scores || '',
                    result: param.result || '',
                    isJoin:false
                })
                await people_info.save()
                return people_info
            }else{
                await answerman.save()
                return answerman
            }
        } catch (error) {
            console.log(error)
        }

    },
    async setOneResult(param) {
        console.log(param)
        try {
            let answerman = null
            answerman = await this.findOne({
                "mobile": param.mobile
            })
        
                answerman.result = param.res
                answerman.scores = param.scores
                answerman.isJoin = true 
                await answerman.save()
                return answerman
            
        } catch (error) {
            console.log(error)
        }

    },
    async updateOne(param,key) {
        console.log(param)
        console.log(key)
        try {
            let answerman = null
            answerman = await this.findOne({
                "mobile": param.mobile
            })
            if (answerman) {
                console.log('已参与')
                // answerman.vcode = param.vcode
                // answerman.scores = param.scores
                // answerman.result = param.result
                // answerman.isJoin = param.isJoin
                answerman[key] = param[key]
                await answerman.save()
                return answerman
            }
        } catch (error) {
            console.log(error)
        }

    },
    async getTopScores(param){
        let size = parseInt(param.size)
        let scoresList = await this.find({},{name:1,mobile:1,scores:1,result:1}).sort({"scores":-1}).limit(size)
        return scoresList
    }
}

const AnswerMan = mongoose.model('AnswerMan', AnswerManSchema)