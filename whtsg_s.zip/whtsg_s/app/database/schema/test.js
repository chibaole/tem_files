/*
 * @Author: 刘攀
 * @Date: 2020-03-11 16:11:13
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-03-16 13:14:45
 * @Description: file content
 */
// var ccap = require('ccap');
// router.get('/verifcode', function(req, res) {
//     function isHas(num, arr) {
//         for (var i = 0; i < arr.length; i++) {
//           if (num == arr[i]) return true;
//         }
//         return false;
//       }


// var codeArr = [];
//      // 用来生成4个随机数
//      while (codeArr.length < 4) {
//        var newNum = Math.floor(Math.random()*10);
//        if (!isHas(newNum, codeArr)) {
//          codeArr.push(newNum);
//        }
//      }
//      console.log(codeArr.join(''))
function equar(a, b) {
  // 判断数组的长度
  if (a.length !== b.length) {
      return false
  } else {
      // 循环遍历数组的值进行比较
      for (let i = 0; i < a.length; i++) {
          if (a[i] !== b[i]) {
              return false
          }
      }
      return true;
  }
}

function compareArraySort(a1,a2){
  if ((!a1 && a2) || (a1 && ! a2)) return false;
  if (a1.length !== a2.length) return false;
      a1 = [].concat(a1);
      a2 = [].concat(a2);
      a1 = a1.sort();
      a2 = a2.sort();
  for (var i = 0, n = a1.length; i < n; i++) {
      if (a1[i] !== a2[i]) return false;
  }
  return true;
}



// let a = ['A']
// let b = ['B','C',"D"]
// let c = ['D','B']
// console.log(compareArraySort(b,c))

let a = ['1','','3']
console.log(a.indexOf('21')) //-1
console.log(a.indexOf(''))//1
