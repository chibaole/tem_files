// 引入https模块，由于我们爬取的网站采用的是https协议
const https = require('https');
const mongoose = require('mongoose')
const rp = require('request-promise')
const crypto = require('crypto');
const hash = crypto.createHash('sha256');

const http = require('http');
let iconv = require('iconv-lite');
const News = mongoose.model('NewsData')
const cheerio = require('cheerio');
let maxpage = 1 //总页数
let current_page = 1 //当前页
let all_news = []
let is_latest = false

function myHttp(methods, url) {
    let promise = new Promise(function (resolve, rejecte) {
        let req = http.get(url)
        req.on("response", function (res) {
            let html = [];
            let length = 0
            res.on("data", function (data) {
                html.push(data)
                length += data.length
            });
            res.on('end', function (date) {
                let data = Buffer.concat(html, length);
                let change_data = iconv.decode(data, 'gb2312');
                html = change_data.toString()
                resolve(html)
            })
        });
    })
    return promise;
}

async function getMaxPage() {
    let url = `http://www.lib.whu.edu.cn/news/default.asp?pageno=${current_page}`;
    let html = await myHttp('get', url)
    //获取总页数
    let $ = cheerio.load(html)
    $("tr[align='right']").each(function () {
        let str = $(this).find('td').eq(0).text().replace(/[\r\n]/g, "").trim()
        var start_inde = str.lastIndexOf("\/");
        var end_index = str.lastIndexOf("\页")
        str = str.substring(start_inde + 1, end_index);
        maxpage = parseInt(str)
    })
}

async function getNews(html, last_time) {
    // //获取总页数
    let $ = cheerio.load(html) //使用这个$对象就像操作jquery对象一般去操作我们获取得到的页面的源代码
    let items = [] //开始采集新闻公告
    let link_host = `http://www.lib.whu.edu.cn/news/view.asp?id=`

    let table_list = $("table[border='1']  tr")
    for (let i = 0; i < table_list.length; i++) {
        

        try {
            if (i >= 2) {
                let item = {
                    type: $(table_list[i]).find('div').eq(0).text().replace(/[\r\n]/g, "").trim(),
                    title: $(table_list[i]).find('a').eq(0).text().replace(/[\r\n]/g, "").trim(),
                    link: $(table_list[i]).find('a').eq(0).attr('href') || '',
                    // time: $(table_list[i]).find('a').eq(1).text().replace(/[\r\n]/g, "").trim()
                    time: $(table_list[i]).find('a').eq(0).attr('title') || $(table_list[i]).find('a').eq(1).attr('title')
                }
                item.link && item.link.includes('javascript') ? item.link = link_host + item.link.replace(/[^0-9]/ig, "") : item.link
                items.push(item)
                
                let current_time = new Date(item.time)
                console.log(current_time)
                if (last_time -  current_time ==0 ) {
                    current_page = maxpage
                    items.length == 15?is_latest=true:is_latest=false//2020-03-06
                    console.log('暂无新信息')
                    return false
                } else {
                    console.log('新数据获取中')
                    await News.setNewsData(item)
                }
            }
        } catch (error) {
            console.log(error)
        }
    }
    all_news = [...all_news, ...items]
    console.log(`这是第${current_page}页\n本页有 ${items.length}条数据\n已获取 ${all_news.length}条`) //获得的公告 通知等集合
}
exports.getNewsLoop = async () => {
    await getMaxPage()
    for (let i = 0; i < maxpage; i++) {
        let url = `http://www.lib.whu.edu.cn/news/default.asp?pageno=${current_page}`;
        let html = await myHttp('get', url)
        getNews(html);
        current_page++
        console.log(current_page,maxpage)
        if (current_page > maxpage) {
            return '获取完毕'
        }
    }
}

//1、确定终止爬取 位置
exports.getNewsEveryday = async () => {
    let res = await News.getFirstOne()
    let last_time = null //已爬取的最新一条信息 时间点
    console.log('已爬取的最新一条信息 时间点')
    res.length == 0?last_time='init':last_time=res[0].time
    await getMaxPage() //爬取最大页数
    console.log(last_time)
    for (let i = 0; i < maxpage; i++) {
        if ( is_latest) {
            console.log('停止爬取')
            return false
        } else {
            console.log('继续')
            let url = `http://www.lib.whu.edu.cn/news/default.asp?pageno=${current_page}`;
            let html = await myHttp('get', url)
            await getNews(html, last_time);
            current_page++
        }
    }

}


exports.getlastOne = async () => {
    let res = await News.testData()
    // console.log(res)
}
exports.getFirstOne = async()=>{
    let res = await News.getFirstOne()
    console.log(res[0].title)
    return res
}



//获取每一页的通知详情信息数据
const news_base_url = 'http://www.lib.whu.edu.cn/news/view.asp'
exports.getNewsDetail = async (param) => {
    let news_id = param.news_id
    let option = {
        uri: `${news_base_url}?id=${news_id}`,
        encoding: null,
        transform: function (body) {
            return iconv.decode(body, 'gb2312');
        }
    }
    let res = await rp(option)
    //提取通知数据
    let $ = cheerio.load(res)
    let title = $('title').text()
    let res_html = $("div[style='margin:15px 20px']").html().replace(/\n/g, '').replace(/\//g, '').toString()
    let res_obj = {
        title: title,
        rich_text: res_html
    }
    return res_obj
}
