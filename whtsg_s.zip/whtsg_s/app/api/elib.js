/*
 * @Author: 刘攀
 * @Date: 2019-10-15 14:57:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-04-16 12:51:29
 * @Description: file content
 */
const mongoose = require('mongoose')
const Suggestion = mongoose.model('Suggestion')
const rp = require('request-promise')
const _ = require('lodash')
const WdBoy = mongoose.model('WdBoy')
const Cfg = mongoose.model('Config')
const OtherApp = mongoose.model('OtherApp')
const Carousel = mongoose.model('Carousel')
const NewsData = mongoose.model('NewsData')
const AnswerMan = mongoose.model('AnswerMan') //互动答题 用户
const Questions = mongoose.model('Questions') //题库
const Intro = mongoose.model('Intro')
const QINIU = mongoose.model('QINIU')
const config = require('../../config/config')
const xml2js = require('xml2js');
const fs = require('fs')
const path = require('path');
const parseXml = (xml) => {
    let {
        parseString
    } = xml2js;
    let res;
    parseString(xml, {
        trim: true,
        explicitArray: false
    }, function (err, result) {
        res = result;
    });
    return res;
}
//关注即持久化 关注的用户  
exports.saveWdBoy = async (message) => {
    //根据open ID 获取 用户的微信信息
    let mp = require('../../wechat/index')
    let client = mp.getWechat()
    let openid = message.FromUserName
    let userInfo = await client.handle('getUserInfo', openid)
    let wd_boy = await WdBoy.findOne({
        openid: openid
    }) //查找已存在的用户
    if (!wd_boy) {
        let boyData = {
            openid: userInfo.openid,
            unionid: userInfo.unionid || null,
            nickname: userInfo.nickname,
            province: userInfo.province,
            country: userInfo.country,
            city: userInfo.city,
            gender: userInfo.gender || userInfo.sex,
            avatar: userInfo.headimgurl,
            //下为需要 elib账号绑定获取数据
            bor_id: '',
            wd_id: '',
            status: '',
            library: '',
            from: 'subscribe'
        }
        wd_boy = new WdBoy(boyData)
        wd_boy = await wd_boy.save()
    } else {
        wd_boy.avatar = wd_boy.headimgurl
        wd_boy.from = 'subscribe'
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}
//前端 获取code 然后保存 用户数据
exports.saveWdBoyBycode = async (userData) => {
    let query = {
        openid: userData.openid
    }
    let wd_boy = await WdBoy.findOne(query)
    if (!wd_boy) {
        wd_boy = new WdBoy({
            openid: userData.openid,
            unionid: userData.unionid || null,
            nickname: userData.nickname,
            province: userData.province,
            country: userData.country,
            city: userData.city,
            gender: userData.gender || userData.sex,
            avatar: userData.headimgurl || '',
            //下为需要 elib账号绑定获取数据
            bor_id: '',
            wd_id: '',
            status: '',
            library: '',
            from: 'front-end'
        })
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}
//取消关注删除 elibuser相关用户  
exports.delWdBoy = async (message) => {
    //删除本openid 的elibuser用户数据
    let mp = require('../../wechat/index')
    let openid = message.FromUserName
    await WdBoy.remove({
        openid: openid
    }, function (error) {
        if (error) {
            console.error(error);
        } else {
            console.error("用户删除成功")
        }
    })
    //删除后用户
    let wd_boy = await WdBoy.findOne({
        openid: openid
    }, function (error, doc) {
        if (error) {
            console.log('删除错误')
        } else {
            console.log('删除成功')
        }
    })
}
exports.updateWdBoy = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = '读者证的id'
        wd_boy.wd_id = ''
        wd_boy = new WdBoy(wd_boy)
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}

//单册信息 、预约列表！、预约请求！、读者认证！、 新书通报！过期列表、借阅历史、获取馆藏信息？？ 、借阅排行、图书封面
// 权限管理 获取session
const wx_login = async () => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    let url = `op=login&user_name=${x_service.user_name}&user_password=${x_service.user_password}&library=${x_service.library}`
    let options = {
        uri: `${x_service.xhost}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn.login['session-id']
}

//读者认证  ----- 
exports.wd_BorValid = async (param) => {
    let bor_id = param.bor_id
    let verification = param.verification
    console.log(param)
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    let url = `user_name=${x_service.user_name}&user_password=${x_service.user_password}&op=bor_auth&bor_id=${bor_id}&verification=${verification}&library=${x_service.library}`
    let options = {
        uri: `${x_service.xhost}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    //获取读者二维码
    const qr_options = {
        uri: `http://apis.juhe.cn/qrcode/api?key=095ba999ef9f2a061fbfd32dff2fa30f&type=1&fgcolor=000000&w=150&m=5&text=${param.data}`,
        json: false
    }
    const data = await rp(qr_options)
    let data_json = JSON.parse(data)
    let qr_bor_id = data_json.result.base64_image
    //更新存储的读者信息
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = bor_id
        wd_boy.wd_id = resJspn['bor-auth']['z303']['z303-id']
        wd_boy.library = resJspn['bor-auth']['z303']['z303-user-library']
        wd_boy.qr_borid = qr_bor_id
        wd_boy = new WdBoy(wd_boy)
        wd_boy = await wd_boy.save()
    }
    return resJspn
}

//读者绑定微信号信息
exports.getBindInfo = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    return wd_boy
}

//读者解绑
exports.wd_unbind = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = ''
        wd_boy.wd_id = ''
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}

//读者信息获取 ----- 可用 需要参数  library 
exports.wd_getUserInfo = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let bor_id = wd_boy.bor_id

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let url = `op=bor_info&bor_id=${bor_id}&verification=123&library=${x_service.library}&format=1`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res)
    return resJspn
}

//检索图书资源
exports.wx_findAll = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt) //x_service 的配置 包括账号 密码 host library 
    console.log(x_service)

    let base = x_service.base
    let request_wd = param.keyword
    let keyword = encodeURI(request_wd);
    let code = param.filedword
    let url = `?op=find&code=${code}&request=${keyword}&base=${base}`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 显示图书资源
exports.wd_present = async (param) => {

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let set_entry = param.set_entry || '000000001-000000010'
    let set_number = param.set_number
    let url = `?op=present&base=${x_service.base}&set_number=${set_number}&set_entry=${set_entry}`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 单册信息
exports.wd_findBook = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let doc_number = param.doc_number || "001246867"
    let url = `?op=item_data_nlc&doc_number=${doc_number}&base=${x_service.base}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//预约列表
exports.wd_holdList = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    let url = `?op=hold_list`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//预约请求
exports.wd_holdBook = async (param) => {

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_id = wd_boy.wd_id || wd_boy.bor_id
    let item_barcode = param.item_barcode
    let url = `?op=hold_req_nlc&id=${wd_id}&item_barcode=${item_barcode}&library=${x_service.library}`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//取消预约
exports.wd_cancelHold = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_id = wd_boy.wd_id || wd_boy.bor_id
    let doc_number = param.doc_number
    let item_sequence = param.item_sequence
    let sequence = param.sequence
    let url = `?op=hold-req-cancel&doc_number=${doc_number}&item_sequence=${item_sequence}&sequence=${sequence}&library=${x_service.library}`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//续借图书
exports.wd_renew = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_bor_id = wd_boy.wd_id || wd_boy.bor_id
    let doc_number = param.doc_number
    let item_sequence = param.item_sequence
    let url = `?op=renew&doc_number=${doc_number}&item_sequence=${item_sequence}&bor_id=${wd_bor_id}&library=${x_service.library}`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 建议留言
exports.suggestion = async (param) => {


    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let suggestion = new Suggestion({
        up_author: {
            openid: openid,
            nickname: wd_boy.nickname,
            avatar: wd_boy.avatar,
            author_id: wd_boy._id
        },
        content: param.content,
        reply: null
    })
    let res = await suggestion.save()
    return {
        success: true
    }
}

//查询读者的建议留言
exports.getSuggestion = async (param) => {
    let res = await Suggestion.find({
        "up_author.openid": param.openid
    }).sort({
        'meta': -1
    })
    return res
}

exports.wd_loanHistory = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let url = `?op=loan_history&bor_id=xtb001&bor_id_type=00`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 新书通报
exports.wd_newbooklist = async (param) => {
    // http://opactest.lib.whu.edu.cn/cgi-bin/newbook_xml.cgi?&library=whu01&shelf_date_from=180&max_entry=100

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)

    let url = `newbook_xml.cgi?library=${x_service.base}&shelf_date_from=180&max_entry=100`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//借阅排行
exports.wd_topBook = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    // http://opactest.lib.whu.edu.cn/cgi-bin/toploan_xml.cgi?&library=whu01&order_key=toptenm&max_entry=100
    let url = `toploan_xml.cgi?&library=${param.library}&order_key=toptenm&max_entry=20`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//图书封面
exports.wx_bookCover = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    let url = `acover.cgi?id=zsl01000123456`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    let res = await rp(options)
    let res_json = parseXml(res)
    return res_json
}

// 借阅历史
// op=loan_history&bor_id=ID51&bor_id_type=00&user_name=www-x&user_password=xxx

// exports.wd_loanHistory
//测试api
exports.get_wd_News = async (param) => {
    let data = {
        title: '武汉大学第四届3D打印设计大赛”获奖名单的通知'
    }
    // let res = await NewsData.getNewsData(param)
    let res = await NewsData.getNewForTime(param)
    return {
        success: 'ok',
        data: res
    }
}


// 图书借阅排行榜  基于elibapi
exports.billboard = async (param) => {
    let currentWallToken = await wallToken()
    let billboardUrl = `wall/ranking/bibLoan?cirtype=${param.cirtype}&libcode=${param.libcode}&page=${param.page}&size=${param.size}`
    let options = {
        uri: `${cfg.elib.other_url}${billboardUrl}`,
        json: true,
        headers: {
            Authorization: currentWallToken
        }
    }
    let res = await rp(options)
    return res
}

// 设置第三方应用 后台设置api
exports.setServer = async (param) => {
    let otherApp = await OtherApp.setApp(param)
    return otherApp
}

//获取配置的第三方应用
exports.getApps = async (param) => {
    let apps = await OtherApp.getApps()
    return apps
}

//删除某个第三方应用
exports.delApp = async (param) => {
    let res = await OtherApp.delApp(param)
    return res
}

//七牛云相关 图片文件存储
const qiniu = require('qiniu')

//上传token获取
exports.uploadToken = async () => {

    let opt = {
        name: 'qiniu'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    // 创建上传凭证
    const accessKey = x_service.accessKey
    const secretKey = x_service.secretKey
    const mac = new qiniu.auth.digest.Mac(accessKey, secretKey)

    let token = await QINIU.getUploadToken()
    if (token) {
        const now = new Date().getTime()
        let expiresIn = token.expires_in
        if (now < expiresIn) {
            return token.token
        } else {
            let options = {
                scope: 'rfid-lp',
                expires: 7200
            }
            let putPolicy = new qiniu.rs.PutPolicy(options)
            let uploadToken = putPolicy.uploadToken(mac)
            //存储到库
            const expiresIn = now + (options.expires - 20) * 1000
            let token_data = {
                uploadtoken: uploadToken,
                expires_in: expiresIn
            }
            await QINIU.saveUploadToken(token_data)
            return uploadToken
        }
    } else {
        let options = {
            scope: x_service.bucket,
            expires: 7200
        }
        let putPolicy = new qiniu.rs.PutPolicy(options)
        let uploadToken = putPolicy.uploadToken(mac)
        //存储到库
        const now = new Date().getTime()
        const expiresIn = now + (options.expires - 20) * 1000
        let token_data = {
            uploadtoken: uploadToken,
            expires_in: expiresIn
        }
        await QINIU.saveUploadToken(token_data)
        return uploadToken
    }
}

//设置轮播图
exports.setCarousel = async (param) => {
    let res = await Carousel.setCarousel(param)
    return res
}

exports.delCarousel = async (param) => {
    let res = await Carousel.delCarousel(param)
    return res
}
exports.getCarousel = async () => {
    let res = await Carousel.getCarousel()
    return res
}

//本地存储图片
exports.uploadfile = async (param) => {
    let files = param

    if (Array.isArray(files.image)) {
        console.log('是个数组,长度为 ： ' + files.image.length)
        let urls = []
        let urls2 = []
        // --------
        for (let i = 0; i < files.image.length; i++) {

            // 创建可读流
            const reader = fs.createReadStream(files.image[i]['path']);
            let filePath = path.join(__dirname, '../../public/img') + `/${ files.image[i]['name']}`;
            let remotefilePath = `http://localhost/img` + `/${ files.image[i]['name']}`;
            // 创建可写流
            const upStream = fs.createWriteStream(filePath);
            // 可读流通过管道写入可写流
            reader.pipe(upStream);
            urls.push(remotefilePath)
            let item = {
                imgurl: remotefilePath
            }
            let res2 = await Carousel.setCarousel(item)
            urls2.push(res2)
        }

        // -------
        return {
            success: 'ok',
            url: urls,
            result: urls2
        }
    } else {
        console.log('不是个数组  ')

        // 创建可读流
        const reader = fs.createReadStream(files['image']['path']);
        let filePath = path.join(__dirname, '../../public/img') + `/${ files['image']['name']}`;
        let remotefilePath = `http://localhost/img` + `/${ files['image']['name']}`;
        // 创建可写流
        const upStream = fs.createWriteStream(filePath);
        // 可读流通过管道写入可写流
        reader.pipe(upStream);
        let item = {
            imgurl: remotefilePath
        }
        let res2 = await Carousel.setCarousel(item)

        return {
            url: remotefilePath,
            result: res2
        }
    }



}

// 小程序相关
exports.wxlogin = async (params) => {
    let appid = config.wechatapp.AppID
    let appsecret = config.wechatapp.AppSecret
    let baseurl = `https://api.weixin.qq.com/sns/jscode2session`
    let options = {
        uri: `${baseurl}?appid=${appid}&secret=${appsecret}&js_code=${params.code}&grant_type=authorization_code`,
        json: true
    }
    let res = await rp(options)
    let openid = res.openid
    return res
}
//  互动答题相关
function isHas(num, arr) {
    for (var i = 0; i < arr.length; i++) {
        if (num == arr[i]) return true;
    }
    return false;
}

exports.sendcode = async (param) => {

    // 存储参与用户信息 名字  手机号 是否参与过
    let set_res = await AnswerMan.setOne(param)
    console.log(set_res)
    // 生成验证码
    var codeArr = [];
    // 用来生成4个随机数
    while (codeArr.length < 4) {
        var newNum = Math.floor(Math.random() * 10);
        if (!isHas(newNum, codeArr)) {
            codeArr.push(newNum);
        }
    }

    let vcode = codeArr.join('')
    let mobile = param.mobile
    console.log(vcode)
    // 更新用户的 验证码
    let update_res = await AnswerMan.updateOne({
        vcode,
        mobile
    }, 'vcode')
    console.log(update_res)
    let options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        uri: 'https://sms.yunpian.com/v2/sms/single_send.json',
        json: true,
        form: {
            apikey: 'ebd181df01638fe398474581b9a194fd',
            mobile: param.mobile,
            text: `【上海阿法迪】您的验证码是${vcode}`
        }
    }
    let send_res = await rp(options)
    return send_res
}

exports.startAnswer = async (param) => {
    let res = await AnswerMan.getOne(param)
    let vcode = res.vcode
    console.log(res)
    if (res.isJoin) {

        return {
            result: "falie",
            message: '只能完成一次答题'
        }
    } else if (param.code && vcode !== param.code) {
        return {
            result: "falie",
            message: '验证码有误'
        }
    } else if (vcode === param.code && !res.isJoin) {

        console.log('可以参见答题')
        return {
            result: "success"
        }
    }

}

//提交答题
function equar(a, b) {
    // 判断数组的长度
    if (a.length !== b.length) {
        return false
    } else {
        // 循环遍历数组的值进行比较
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) {
                return false
            }
        }
        return true;
    }
}
// 比较答案
function compareArraySort(a1,a2){
    if ((!a1 && a2) || (a1 && ! a2)) return false;
    if (a1.length !== a2.length) return false;
        a1 = [].concat(a1);
        a2 = [].concat(a2);
        a1 = a1.sort();
        a2 = a2.sort();
    for (var i = 0, n = a1.length; i < n; i++) {
        if (a1[i] !== a2[i]) return false;
    }
    return true;
  }

exports.submit = async (param) => {
    let result_data = param.res //[] [ { cid: '4', key: 'right', type: 'true_false' } ]  用户答案
    let answer_res = await Questions.getAnswer() // {type:'radio',answer:['A']} 所有问题答案
    let right_res = []
    let wrong_res = []
    for (let j = 0; j < result_data.length; j++) {
        //找出对应的问题  -- 对比答案结果
        for (let i = 0; i < answer_res.length; i++) {
            if (result_data[j].cid === answer_res[i].cid && compareArraySort(result_data[j].key, answer_res[i].answer)) {
                right_res.push(result_data[j]) //回答对的问题
            } else if(result_data[j].cid === answer_res[i].cid ){
                wrong_res.push(result_data[j])
            }
        }
    }
    let scores = right_res.length * 10
    let user_result = {
        mobile: param.mobile  ,
        scores: scores,
        res: {
            right: right_res,
            wrong: wrong_res,
            dur_time: param.dur_time
        }
    }
    let res_scores = await AnswerMan.setOneResult(user_result)
    let res = {
        scores: res_scores.scores,
        rigth: res_scores.result.right.length,
        wrong: res_scores.result.wrong.length
    }
    return res


}

//上传题库
const questions_data = require('../../config/question')
console.log(questions_data.data.length)
exports.upload_question = async (param) => {
    
    for (let i = 0; i < param.data.length; i++) {
        let res = await Questions.setitem(param.data[i])
        console.log(res.length)
    }
    return {
        msg: '上传完成'
    }
}

// 获取题库

exports.get_question = async (param) => {
    let res = await Questions.getAllQuestion(param)
    return res
}

exports.scoresList = async(param)=>{
    let res = await AnswerMan.getTopScores(param)
    return res
}

// 上传 活动介绍
exports.post_intro = async(param)=>{
    let res = await  Intro.setOne(param)
    return res
}
exports.get_intro = async()=>{
    let res = await Intro.getOne()
    return res
}