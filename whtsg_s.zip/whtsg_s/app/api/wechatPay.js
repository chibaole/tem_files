const crypto = require('crypto');
const xml2js = require('xml2js');
const rp = require('request-promise')
const config = require('../../config/config')

const prepay_url = 'https://api.mch.weixin.qq.com/pay/unifiedorder'; //统一下单接口地址
const notify_url = 'http://server.lpfyy.cn/wx_pay_res'; //异步接收微信支付结果通知的回调地址，通知url必须为外网可访问的url，不能携带参数。

const mongoose = require('mongoose')

const Cfg = mongoose.model('Config')
let cfg = {}

exports.prepay = async (params) => {
    cfg = await Cfg.findOne({
        name: 'config'
    })
    console.log(cfg)

    let obj = {
        appid: cfg.wechat.appID,
        mch_id: cfg.wechat.mch_id,
        nonce_str: get_nonce_str(32),
        body: params.desc,
        out_trade_no: params.orderid,
        total_fee: parseInt(params.totalPrice * 100),
        spbill_create_ip: params.spbill_create_ip,
        notify_url: notify_url,
        trade_type: 'JSAPI',
        openid: params.openid
    }
    let arr = Object.keys(obj).sort().map(item => {
        return `${item}=${obj[item]}`;
    });
    let str = arr.join('&') + '&key=' + cfg.wechat.key;
    obj.sign = getSign(str);
    let res;
    try {
        // 调用微信统一下单接口拿到 prepay_id
        res = await wechatPay(obj);
        let {
            prepay_id
        } = res;
        if (prepay_id) {
            res = getClientPayConfig(prepay_id)
            return res;
        }
    } catch (e) {
        res = e;
    }
}

/**
 * 
 * @param {String} prepay_id
 */
const getClientPayConfig = (prepay_id) => {
    let obj = {
        appId: cfg.wechat.appID,
        timeStamp: String(Math.floor(Date.now() / 1000)),
        nonceStr: get_nonce_str(32),
        package: 'prepay_id=' + prepay_id,
        signType: 'MD5'
    }
    let arr = Object.keys(obj).sort().map(item => {
        return `${item}=${obj[item]}`;
    });
    let str = arr.join('&') + '&key=' + cfg.wechat.key;
    obj.paySign = getSign(str);
    return obj;
}

/**
 * @param {Object} obj 调用统一下单的必须参数
 */
const wechatPay = async (obj) => {
    let xml = json2xml(obj);
    var options = {
        method: 'POST',
        uri: prepay_url,
        body: xml,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res).xml;
    return resJspn
}

/**
 * md5加密
 * @param {String} str
 */
const getSign = (str) => {
    let hash = crypto.createHash('md5').update(str, 'utf8');
    return hash.digest('hex').toUpperCase();
}

/**
 * 转化xml
 * @param {Object} obj
 */
const json2xml = (obj) => {
    let builder = new xml2js.Builder({
        headless: true,
        allowSurrogateChars: true,
        rootName: 'xml',
        cdata: true
    });
    var xml = builder.buildObject(obj);
    return xml;
}

const parseXml = (xml) => {
    let {
        parseString
    } = xml2js;
    let res;
    parseString(xml, {
        trim: true,
        explicitArray: false
    }, function (err, result) {
        res = result;
    });
    return res;
}

/**
 * 生成指定长度的随机数
 * @param {*int} len
 */
const get_nonce_str = (len) => {
    let str = '';
    while (str.length < len) {
        str += Math.random().toString(36).slice(2);
    }
    return str.slice(-len);
}