/*
 * @Author: 刘攀
 * @Date: 2020-03-03 10:56:13
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-03-05 15:06:03
 * @Description: file content
 */
// const crypto = require('crypto');
// const hash = crypto.createHash('sha256');
// hash.update('0000')
// let res = hash.digest('hex')
// console.log(res)
// const mongoose = require('mongoose')

// // const News = mongoose.model('NewsData')

// // async function getCurrentID(){
// //     let res = await News.getFirstOne()
// //     console.log(res)
// //     let last_id = res._id
// // }
// // getCurrentID()


// let rows = [
//     {"time":'2020/2/10'},
//     {"time":'2020/2/10'},
//     {"time":'2020/1/3'},


//     {"time":'2020/3/3'},
//     {"time":'2020/3/1'},

// ]
// let re = rows.sort(function(a,b){
//     return Date.parse(a.time) - Date.parse(b.time)
// })
// console.log(re)
// console.log(Date(rows[0].time))

// let a = 1 ,b=2;
// function test(){
//     if(a<b){
//         return true
//     }else{
//         return false
//     }
// }
// function test1(){
//     return a>b
// }
// let d = test()
// let c = test1()
// console.log(c,d )

// //定时模块定时启动抓取数据函数函数
// const schedule = require('node-schedule');

// let rule     = new schedule.RecurrenceRule();
// // let times    = [1,3,5,7,9,11,14,15,17,19,21,23];
// // rule.hour  = times;
// // rule.minute = 30;
// rule.second = [10,20,30,40,50]
// schedule.scheduleJob(rule, function(){
//     console.log(c,d );
// });

// let a = '2007/4/16 14:27:00'
// let b = new Date('2007-04-16T06:27:00.000+00:00')
// console.log(a)
// console.log(b)
// let c = new Date(a)
// console.log(c)
// if(b-c == 0){
//     console.log(1)
// }else{
//     console.log(2)
// }

// let arr =[1,2,3,4,5]
// arr.forEach((item,index)=>{
//     console.log(item,index)
// })

// let a ='http://localhost/img/jinbao.jpg'
// let b= a.replace('localhost','刘攀')
// console.log(b)
let arr = [1,2,3,4,5,6]
let mapped = arr.map(el=> el+20)
// console.log(mapped)
let filtered = arr.filter(el=>el >2 )
// console.log(filtered)

let rueduced = arr.reduce((pre,item)=>{
    return pre + item
},0)
let reduced = arr.reduce((total,current)=>total+current)

console.log(reduced)
let arr2 = [1,2,3,4,5,6,7]
// arr2.splice(2,2,'哈')
let sliced = arr2.slice(1,4)
console.log(arr2)
console.log(sliced)
let arr3 = [1,2,3,-1,-2,3,9,10,3,4,5,6,-9]
let sorted = arr3.sort((el1,el2)=>{
    return el1 -el2
})
console.log(sorted)
const greeter = new Promise((res,rej)=>{
    // callbackfun((result)=>{
    //     res(result)
    // })
    setTimeout(()=>{
        res('山楂树')
    },1000)
})
async function myfn(){
    let res = await greeter;
    console.log(res)
}
myfn()