/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:23:16
 * @Description: file content
 */
module.exports = {
  wechat: require('./wechat'),
  elib: require('./elib'),
  wxPay: require('./wechatPay'),
  spilder: require('./spider')
}