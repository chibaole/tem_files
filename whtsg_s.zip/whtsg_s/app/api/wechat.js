/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-19 16:23:18
 * @Description: file content
 */
const {
  resolve
} = require('path')

const mongoose = require('mongoose')
const ElibUser = mongoose.model('ElibUser')
const Temp = mongoose.model('Temp')
const Cfg = mongoose.model('Config')

const {
  getOAuth,
  getWechat
} = require('../../wechat/index')
const util = require('../../wechat-lib/util')
const rp = require('request-promise')

exports.getSignature = async (url) => {
  const client = getWechat()
  const data = await client.fetchAccessToken()
  const token = data.access_token
  const ticketData = await client.fetchTicket(token)
  const ticket = ticketData.ticket

  let params = util.sign(ticket, url)
  params.appId = await client.appID()
  console.log('获取微信配置参数')
  console.log(params)
  return params
}
exports.getTicket = async (url) => {
  console.log(url)
  const client = getWechat()
  const data = await client.fetchAccessToken()
  const token = data.access_token
  const ticketData = await client.fetchTicket(token)
  const ticket = ticketData.ticket
  let params = util.sign(ticket, url)
  params.appId = await client.appID()

  return params


}
// 获取二维码
exports.getQRcode = async (param) => {
  const options = {
    uri: `http://apis.juhe.cn/qrcode/api?key=095ba999ef9f2a061fbfd32dff2fa30f&type=1&fgcolor=000000&w=150&m=5&text=${param.data}`,
    json: false
  }

  const data = await rp(options)

  let data_json = JSON.parse(data)
  let elibuser = await ElibUser.findOneAndUpdate({
    openid: param.openid
  }, {
    $set: {
      qr_rdrno: data_json.result.base64_image || '二维码？'
    }
  }, {
    new: true
  })
  return data
}

exports.getAuthorizeURL = (scope, target, state) => {
  console.log('getAuthorizeURL')
  const oauth = getOAuth()
  const url = oauth.getAuthorizeURL(scope, target, state)
  return url
}

exports.getUserinfoByCode = async (code) => {
  const oauth = getOAuth()
  const data = await oauth.fetchAccessToken(code)
  const userData = await oauth.getUserInfo(data.access_token, data.openid)
  return userData
}


// 新增 获取 模版消息
exports.getTemMessage = async () => {
  const client = getWechat()
  const data = await client.fetchAccessToken()
  const token = data.access_token
  let res = await client.handle('getTemMessage', token)
  let temp_list = res.template_list
  await Temp.remove()
  let typelist = ['hd_bm', 'ts_ch', 'ts_cq', 'ts_jy']

  for (let i = 0; i < temp_list.length; i++) {
    let type = 'other'

    // type = typelist[i]
    if (temp_list[i].title.indexOf('活动报名') != -1) {
      type = 'hd_bm'
    } else if (temp_list[i].title.indexOf('还书') != -1) {
      type = 'ts_ch'

    } else if (temp_list[i].title.indexOf('图书超期') != -1) {
      type = 'ts_cq'
    } else if (temp_list[i].title.indexOf('借书成功') != -1) {
      type = 'ts_jy'
    }
    let tem_item = new Temp({
      title: temp_list[i].title,
      template_id: temp_list[i].template_id,
      type: type,
      data: temp_list[i].content
    })
    tem_item = await tem_item.save()
  }
  return res
}
// 发送模版消息
exports.sendTemMessage = async (param) => {
  console.log('发送模版消息 api')
  console.log(param)
  let type = param.type
  let rdrno = param.rdrno

  let tem_item = await Temp.findOne({
    type: type
  })
  let elibuser = await ElibUser.findOne({
    rdrno: rdrno
  })
  let senddata = {
    touser: elibuser.openid,
    template_id: tem_item.template_id,
    data: param.param
  }
  let mp = require('../../wechat/index')
  let client = mp.getWechat()
  let res = await client.handle('sendTemplateMessage', senddata)
  console.log('发送模版消息 api OK')
  return res
}

//上传素材
exports.uploadMaterial = async (param) => {
  console.log('上传素材 api')
  console.log(param)
  let mp = require('../../wechat/index')
  let client = mp.getWechat()
  let data = await client.handle('uploadMaterial', 'image', resolve(__dirname, '../../qingyuanlog.jpg'), {
    type: 'image'
  })

  let articles = []

  for (let i = 0; i < param.length; i++) {
    let item = {
      title: '',
      thumb_media_id: data.media_id,
      author: '',
      digest: '',
      show_cover_pic: '',
      content: '',
      content_source_url: ''
    }
    item.title = param[i].title
    item.author = param[i].author,
      item.digest = param[i].digest,
      item.show_cover_pic = param[i].show_cover_pic,
      item.content = param[i].content,
      item.content_source_url = param[i].content_source_url

    articles[articles.length] = item
    // this.libcodes[length] = res.data.rows[i].libcode;

  }
  console.log(articles)
  let media = {
    articles: articles
  }
  let uploadData = await client.handle('uploadMaterial', 'news', media, {})

  console.log(uploadData)
  return uploadData

}

//获取素材列表
exports.batchMaterial = async (param) => {
  let mp = require('../../wechat/index')
  let client = mp.getWechat()
  let counts = await client.handle('countMaterial')
  console.log(JSON.stringify(counts))
  let options = {
    type: param.type,
    offset: param.offset,
    count: param.count
  }
  let res = await Promise.all([
    client.handle('batchMaterial', options),
  ])
  return res
}

//payJs 获取微信的openid

exports.getopenIDUrl = async (param) => {
  let options = {
    uri: `https://payjs.cn/api/openid?mchid=${param.mchid}&callback_url=${param.callback_url}`,
    json: true
  }
  console.log(options.uri)
  let res = await rp(options)
  return res

}



// 设置公众号

exports.setConfig = async (param) => {
  //获取 app ID appsecret
  console.log('设置公众号')
  console.log(param)

  let options = {
    name: param.title,
    title: param.title,
    AppID: param.appID,
    AppSecret: param.appSecret,
    Token: param.token,
    redirect_uri: param.redirect_uri,
    elib_account: param.account,
    elib_password: param.password,
    elib_client_id: param.client_id,
    elib_baseurl: param.baseurl,
    other_url: param.other_url,
    autordrno: param.autordrno || '自动条码区间代码',

    rdrtype: param.rdrtype,
    mch_id: param.mch_id,
    key: param.key,

  }
  let res = await Cfg.setConfig(options)
  return res
}

//获取数据库已存在的 公众号设置
exports.fetchConfig = async () => {
  //获取 app ID appsecret
  let res = await Cfg.getConfig()


  return res
}
//获取菜单列表
exports.menuList = async () => {
  let mp = require('../../wechat/index')
  let client = mp.getWechat()
  let res = await client.handle('fetchMenu')
  return res
}
exports.updateMenu = async (menu) => {
  console.log(menu)
  console.log('开始删除菜单')

  let mp = require('../../wechat/index')
  let client = mp.getWechat()
  console.log('开始删除菜单')

  let res1 = await client.handle('deleteMenu')
  console.log('删除菜单完毕')
  console.log(res1)
  let res2 = await client.handle('createMenu', menu)
  console.log(res2)
  return res2
}

// 新的配置形式 公众号相关
exports.get_param_info = async (params)=>{
  console.log(params)
  let res =await Cfg.get_param_info(params)
  // console.log(res)
  return res
}
exports.set_param_info = async(params)=>{
  let res =await Cfg.set_param_info(params)
  return res
}