/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-04-21 14:19:18
 * @Description: file content3
 */


const { resolve } = require('path')
const isProd = process.env.NODE_ENV === 'production'
// 

let cfg = {
  port: 3008,
  db:'mongodb://127.0.0.1:27017/WechatCulturalCenter',
  wechatapp:{
    AppID:'wxb95fbdbd8603b78c',
    AppSecret:'86d87bf6d31484e1423485d2fd9fb76e'
  }

}

if (isProd) {
  const config = require(resolve(__dirname, '../../../../config/config.json'))
  cfg = Object.assign(cfg, config)
  console.log('配置信息')
  console.log(cfg)
}

module.exports = cfg


