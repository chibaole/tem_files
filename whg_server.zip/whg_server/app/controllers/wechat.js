/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-06 16:19:05
 * @Description: file content
 */
const {
  reply
} = require('../../wechat/reply')
const api = require('../api/index')
const wechatMiddle = require('../../wechat-lib/middleware')
const mongoose = require('mongoose')


// 新的配置
const WHGConfig = mongoose.model('WHGConfig')
let whg_config = {}
async function init() {

  whg_config = await WHGConfig.getConfig()
}
// 新的配置

exports.getSDKSignature = async (ctx, next) => {

  let url = ctx.query.url
  url = decodeURIComponent(url)
  const params = await api.wechat.getSignature(url)
  ctx.body = {
    success: true,
    data: params
  }
}

exports.getTicket = async (ctx, next) => {
  let url = ctx.query.url
  let res = await api.wechat.getTicket(url)
  ctx.body = {
    success: true,
    data: res
  }
}

// 接入微信消息中间件
exports.sdk = async (ctx, next) => {
  const url = ctx.href
  const params = await api.wechat.getSignature(url)
  await ctx.render('wechat/sdk', params)
}

// 接入微信消息中间件
exports.hear = async (ctx, next) => {
  console.log('接入微信消息中间件')
  await init()
  console.log(whg_config.wechat)
  const middle = wechatMiddle(whg_config.wechat, reply)
  await middle(ctx, next)
}

exports.menuList = async (ctx, next) => {
  // ctx.query.
  await init()

  const middle = wechatMiddle(whg_config.wechat, reply)
  await middle(ctx, next)

}


exports.oauth = async (ctx, next) => {
  console.log('微信 重定向的url、携带code')
  await init()
  console.log(whg_config.wechat)

  const state = ctx.query.id
  const scope = 'snsapi_base' //snsapi_userinfo
  const target = whg_config.wechat.redirect_url
  console.log(scope, target, state)
  const url = await api.wechat.getAuthorizeURL(scope, target, state)
  ctx.body = url
}

exports.userinfo = async (ctx, next) => {
  let param = ctx.query
  ctx.body = '测试'
  const userData = await api.wechat.getUserinfoByCode(ctx.query.code)

  // ctx.body = userData
}
exports.getUserInfo = async (ctx, next) => {
  let param = ctx.query
  const userData = await api.wechat.getUserinfoByCode(ctx.query.code)
  await api.elib.saveElibUserBycode(userData)
  ctx.body = userData
}

exports.getQRcode = async (ctx, next) => {
  await init()

  let param = ctx.request.body

  let qr = await api.wechat.getQRcode(param)
  ctx.body = qr

}

exports.getTemMessage = async (ctx, next) => {
  let res = await api.wechat.getTemMessage()
  ctx.body = res
}
exports.test = async (ctx, next) => {
  console.log('接入微信消息中间件')

  ctx.body = '测试'
}
exports.sendTemMessage = async (ctx, next) => {
  let param = ctx.request.body
  let res = await api.wechat.sendTemMessage(param)
  ctx.body = res
}

//上传素材
exports.uploadMaterial = async (ctx, next) => {
  let param = ctx.request.body.articles
  console.log('上传素材 controller 获取的参数')
  console.log(param)
  let res = await api.wechat.uploadMaterial(param)
  ctx.body = res
}
//获取所有素材列表
exports.batchMaterial = async (ctx, next) => {
  let param = ctx.query
  let res = await api.wechat.batchMaterial(param)
  ctx.body = res
}


// // 微信支付
exports.wxPayOrder = async (ctx, next) => {
  console.log('微信支付')
  var ip = ctx.headers['x-forwarded-for'] ||
    ctx.ip ||
    ctx.connection.remoteAddress ||
    ctx.socket.remoteAddress ||
    ctx.connection.socket.remoteAddress || '';
  if (ip.split(',').length > 0) {
    ip = ip.split(',')[0]
  }
  ip = ip.substr(ip.lastIndexOf(':') + 1, ip.length);

  console.log('客户端ip')
  let param = ctx.query
  param['spbill_create_ip'] = ip
  console.log(param)
  let res = await api.wxPay.prepay(param)
  console.log(res)
  ctx.body = res
}
//微信支付实名认证

exports.realNameAuth = async (ctx, next) => {
  console.log('微信实名认证')
  let params = ctx.query
  console.log(params)
  let res = await api.wxPay.realNameAuth(params)
  ctx.body = res
}

exports.auth_code_url = async (ctx, next) => {
  let params = ctx.query
  console.log(params)
  let res = await api.wxPay.auth_code_url(params)
  ctx.body = res
}

exports.payjsAPI = async (ctx, next) => {
  let param = ctx.query
  let res = await api.wxPay.payjsAPI(param)
  ctx.body = res
}



exports.getopenIDUrl = async (ctx, next) => {
  let param = ctx.query
  let res = await api.wechat.getopenIDUrl(param)
  ctx.body = res
}
// 后台使用的

exports.setConfig = async (ctx, next) => {

  let param = ctx.request.body
  let res = await api.wechat.setConfig(param)
  ctx.body = res
}

exports.fetchConfig = async (ctx, next) => {

  let res = await api.wechat.fetchConfig()

  ctx.body = res
}


//获取菜单列表
exports.menuListNew = async (ctx, next) => {
  let res = await api.wechat.menuList()
  ctx.body = res
}

//更新菜单
exports.updateMenu = async (ctx, next) => {
  let menu = ctx.request.body
  console.log(menu)
  let res = await api.wechat.updateMenu(menu)
  ctx.body = res
}

// 测试
exports.test = async (ctx, next) => {
  console.log('测试一下')
  ctx.body = '测试'

  await next()
}