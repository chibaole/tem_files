/*
 * @Author: 刘攀
 * @Date: 2019-10-15 14:57:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-06 16:36:24
 * @Description: file content
 */
const mongoose = require('mongoose')
const Suggestion = mongoose.model('Suggestion')
const rp = require('request-promise')
const _ = require('lodash')
const ElibUser = mongoose.model('ElibUser')

const OtherApp = mongoose.model('OtherApp')
const Carousel = mongoose.model('Carousel')
const QINIU = mongoose.model('QINIU')
// 文化馆配置
const WHGConfig = mongoose.model('WHGConfig')
// 普通elibtoken
let cfg = {}

const updateToken = async () => {

    cfg = await WHGConfig.findOne({
        name: 'config'
    })
    let getTokenUrl = `common/validateClient.do?client_id=${cfg.elib.client_id}&account=${cfg.elib.account}&password=${cfg.elib.password}`
    const options = {
        uri: ` ${cfg.elib.baseurl}${getTokenUrl}`,
        json: true
    }
    console.log(options.uri)
    const data = await rp(options)
    if (data.status === '9999') {
        return false
    }
    return data.rows[0].token

}
// 大屏wall token
const wallToken = async (arg) => {
    let cfg = await WHGConfig.findOne({
        name: 'config'
    })
    let getTokenUrl = `wall/auth/token`
    let uri = ''
    if (arg) {
        uri = `${arg}${getTokenUrl}`

    } else {
        uri = `${cfg.elib.other_url}${getTokenUrl}`
    }
    console.log(uri)
    var options = {
        method: 'POST',
        uri: uri,
        body: {
            client_id: cfg.elib.client_id,
            username: cfg.elib.account,
            password: cfg.elib.password
        },
        json: true
    };
    const data = await rp(options)
    return data.token
}
//文化馆相关接口

exports.whg_test = async () => {

    let whg_config = await WHGConfig.getConfig()
    return whg_config
}
/*保存设置 系统配置  */
exports.saveConfig = async (params) => {
    let res = await WHGConfig.setConfig(params)
    return res
}
/* 获取系统配置 */
exports.whgConfig = async (params) => {
    let res = await WHGConfig.getConfig(params)
    return res
}
/* 读者登录 */

exports.bindOpenid = async (param) => {
    // http://jsdz7.mynetgear.com:8883/activity/libcirreader/checklogin?rdrno=123&password=123
    // http://jsdz7.mynetgear.com:8883/activity/libcirreader/checklogin?rdrno=123&password=123
    let bindUrl = `activity/libcirreader/checklogin?rdrno=${param.rdrno}&password=${param.password}`
    let options = {
        uri: `${cfg.elib.baseurl}${bindUrl}`,
        json: true
    }
    let res = await rp(options)

    //   本地存储 对应用户的读者证号
    let openid = param.openid || 'oy8FZwgBDy58PM049KOCSYjS4HS4'

    /*  let elibuser = await ElibUser.findOneAndUpdate({
             openid: openid
         }, {
             $set: {
                 rdrid: res.rows[0].id || '未获取读者ID',
                 rdrno: res.rows[0].rdrno || '未获取读者证号码',
                 status: res.rows[0].status,
                 rdrtype: res.rows[0].rdrtype,
                 libcode: res.rows[0].libcode,
                 createdate: res.rows[0].createdate,
                 enddate: res.rows[0].enddate,
             }
         }, {
             new: true
         }

     ) */
    return res
}

exports.checklogin = async (param) => {
    let whg_config = await WHGConfig.getConfig()

    let bindUrl = `activity/libcirreader/checklogin?rdrno=${param.rdrno}&password=${param.password}`
    let options = {
        uri: `${whg_config.elib.baseurl}${bindUrl}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    return res
}

/* 文化馆活动列表 */
exports.activity_list = async (params) => {
    console.log(params)
    let whg_config = await WHGConfig.getConfig()
    let activityUrl = `activity/activity/listbyotherterm?`
    let options = {
        uri: `${whg_config.elib.baseurl}${activityUrl}page=${params.page}&rows=${params.rows}&sortBy=${params.sortBy}`,
        json: true
    }
    let res = await rp(options)
    return res
}
/* 身边的文化馆 */
exports.nearbyLibrary = async (params) => {
    // http://jsdz7.mynetgear.com:8883/activity/parsyscoordinates/list?page=1&rows=12&sortBy=loccode%20desc
    console.log(params)
    let whg_config = await WHGConfig.getConfig()
    let activityUrl = `activity/parsyscoordinates/list?`
    let options = {
        uri: `${whg_config.elib.baseurl}${activityUrl}page=${params.page}&rows=${params.rows}&sortBy=${params.sortBy}`,
        json: true
    }
    let res = await rp(options)
    return res
}
/* 基于高德地图的IP定位 */
exports.getLocationIP = async (params) => {

    // https://restapi.amap.com/v3/ip?key=4bede5207aa6fbbda91b5807c9a7a284&ip
    let options = {

        uri: `https://restapi.amap.com/v3/ip?key=4bede5207aa6fbbda91b5807c9a7a284&ip=${params.ip}`,
        json: true
    }
    let res = await rp(options)
    return res
}









// 图书检索
exports.searchBookBykeyword = async (param) => {

    let currentToken = await updateToken()
    let keyword = encodeURI(param.keyword);
    let filedword = encodeURI(param.filedword);
    let searchBookurl = `book/listBib.do?field=${filedword}&keyword=${keyword}&token=${currentToken}&rows=${param.rows}&start=${param.start}`
    const options = {
        uri: `${cfg.elib.baseurl}${searchBookurl}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    return res
}
// 馆藏检索
exports.listHoldings = async (param) => {

    let currentToken = await updateToken()
    let liburl = `holding/listHoldings.do?bibid=${param.bibid}&token=${currentToken}`

    const options = {
        uri: `${cfg.elib.baseurl}${liburl}`,
        json: true
    }

    let res = await rp(options)
    return res
}
//馆藏信息
exports.holding = async (param) => {

    let currentToken = await updateToken()
    let holdingUrl = `holding/getHoldingInfo.do?barcode=${param.barcode}&token=${currentToken}`
    const options = {
        uri: `${cfg.elib.baseurl}${holdingUrl}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)

    return res

}

//图书封面

exports.getCoverImage = async (param) => {
    console.log(param)
    let baseurl = 'http://192.168.0.211:8180/opac/par/common/getDoubanBook.do'
    let currentToken = await updateToken()
    const options = {
        uri: `${baseurl}`,
        json: true,
        formData: {
            isbn: param.isbn
        },
        method: 'POST'

    }
    console.log(options.uri)
    let res = await rp(options)
    console.log(res)
    return res
}

// 预约图书
exports.reservation = async (param) => {
    let currentToken = await updateToken()

    let openid = param.openid
    let elibuser = await ElibUser.findOne({
        openid: openid
    })

    let reserva_url = `reserve/addReserve.do?rdrno=${elibuser.rdrno}&restype=${param.restype}&bibid=${param.bibid}&token=${currentToken}`
    let options = {
        uri: `${cfg.elib.baseurl}${reserva_url}`,
        json: true
    }
    let res = await rp(options)
    return res

}
// 图书借阅排行榜
exports.billboard = async (param) => {
    let currentWallToken = await wallToken()
    let billboardUrl = `wall/ranking/bibLoan?cirtype=${param.cirtype}&libcode=${param.libcode}&page=${param.page}&size=${param.size}`
    let options = {
        uri: `${cfg.elib.other_url}${billboardUrl}`,
        json: true,
        headers: {
            Authorization: currentWallToken
        }
    }
    console.log(options.uri)
    let res = await rp(options)
    return res

}

// 图书管办证/ 或者新增网上读者
exports.applyID = async (param) => {
    let currentToken = await updateToken() //elib授权token
    let username = encodeURI(param.name);
    let applyIDUrl = `reader/addReader.do?rdrtype=${cfg.elib.rdrtype }&autordrno=${cfg.elib.autordrno}&name=${username}&idcard=${param.idcard}&token=${currentToken}&checkidcard=1`
    const options = {
        uri: `${cfg.elib.baseurl}${applyIDUrl}`,
        json: true
    }
    console.log(options.uri)

    let res = await rp(options)
    //  本地存储 对应用户的读者证号
    let openid = param.openid

    let elibuser = await ElibUser.findOneAndUpdate({
            openid: openid
        }, {
            $set: {
                rdrid: res.rows[0].id || '未获取读者ID',
                rdrno: res.rows[0].rdrno || '未获取读者证号码',
                status: res.rows[0].status,
                rdrtype: res.rows[0].rdrtype,
                libcode: res.rows[0].libcode,
                createdate: res.rows[0].createdate,
                enddate: res.rows[0].enddate,
            }
        }, {
            new: true
        }

    )
    return res
}
//关注即持久化 elib用户  
exports.saveElibUser = async (message) => {
    //根据open ID 获取 用户的微信信息
    console.log('根据open ID 获取 用户的微信信息')
    let mp = require('../../wechat/index')
    let client = mp.getWechat()
    let openid = message.FromUserName
    let userInfo = await client.handle('getUserInfo', openid)

    let elibuser = await ElibUser.findOne({
        openid: openid
    }) //查找已存在的用户
    console.log('根据用户openid 先查找用户信息表')
    if (!elibuser) {
        console.log('不存在的用户')
        let userData = {
            openid: userInfo.openid,
            unionid: userInfo.unionid || null,
            nickname: userInfo.nickname,
            province: userInfo.province,
            country: userInfo.country,
            city: userInfo.city,
            gender: userInfo.gender || userInfo.sex,
            avatar: userInfo.headimgurl,
            //下为需要 elib账号绑定获取数据
            rdrid: '',
            rdrno: '',
            qr_rdrno: '',
            status: '',
            rdrtype: '',
            libcode: '',
            createdate: '',
            enddate: '',
            from: 'subscribe'
        }
        elibuser = new ElibUser(userData)
        elibuser = await elibuser.save()
    } else {
        console.log('已存在的用户')

        elibuser.avatar = userInfo.headimgurl
        elibuser.from = 'subscribe'
        elibuser = await elibuser.save()

    }
    return elibuser

}
//前端 获取code 然后保存 用户数据
exports.saveElibUserBycode = async (userData) => {
    let query = {
        openid: userData.openid
    }

    let elibuser = await ElibUser.findOne(query)

    if (!elibuser) {
        elibuser = new ElibUser({
            openid: userData.openid,
            unionid: userData.unionid || null,
            nickname: userData.nickname,
            province: userData.province,
            country: userData.country,
            city: userData.city,
            gender: userData.gender || userData.sex,
            avatar: userData.headimgurl || '',
            //下为需要 elib账号绑定获取数据
            rdrid: '',
            rdrno: '',
            qr_rdrno: '',
            status: '',
            rdrtype: '',
            libcode: '',
            createdate: '',
            enddate: '',
            from: 'front-end'

        })
        elibuser = await elibuser.save()
    }
    console.log('//前端 获取code 然后保存 用户数据')
    return elibuser
}
/* 文化馆 绑定读者 账号信息 */
exports.bindWHGID = async (param) => {

    //   本地存储 对应用户的读者证号
    console.log('本地存储 对应用户的读者证号')
    console.log(param)
    let openid = param.openid
    let elibuser = await ElibUser.findOneAndUpdate({
        openid: openid
    }, {
        $set: {
            rdrno: param.rdrno || '未获取读者证号码',
            rdrpwd: param.pwd,
        }
    }, {
        new: true
    })
    return elibuser
}
//取消关注删除 elibuser相关用户  
exports.delElibUser = async (message) => {
    //删除本openid 的elibuser用户数据
    let mp = require('../../wechat/index')
    let client = mp.getWechat()
    let openid = message.FromUserName

    await ElibUser.remove({
        openid: openid
    }, function (error) {
        if (error) {
            console.error(error);
        } else {
            console.error("用户删除成功")
        }
    })
    //删除后用户
    let elibuser = await ElibUser.findOne({
        openid: openid
    }, function (error, doc) {
        if (error) {
            console.log('删除错误')
        } else {
            console.log('删除成功')
        }
    })


}
exports.updateUser = async (param) => {
    let openid = param.openid
    let elibuser = await ElibUser.findOne({
        openid: openid
    })

    if (elibuser) {
        elibuser.rdrid = '读者证的id'
        elibuser.rdrno = '读者证号码'
        elibuser = new ElibUser(elibuser)
        elibuser = await elibuser.save()
    }
    return elibuser
}
// 获取系统信息
exports.systemInfo = async (param) => {

    let currentToken = await updateToken() //elib授权token
    let systemurl = `common/getParameter.do?key=${param.key}&token=${currentToken}`
    let options = {
        uri: `${cfg.elib.baseurl}${systemurl}`,
        json: true
    }
    let res = await rp(options)
    return res

}
//读者是否绑定信息
exports.getBindInfo = async (param) => {
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    if (elibuser && elibuser.rdrno && elibuser.rdrid) {
        //绑定过账号
        return elibuser
    } else {
        return false
    }
}
// 绑定读者证
exports.bindWechatID = async (param) => {
    let currentToken = await updateToken() //elib授权token
    let bindUrl = `reader/bindOpenid.do?id=${param.id}&openid=${param.openid}&token=${currentToken}`
    let options = {
        uri: `${cfg.elib.baseurl}${bindUrl}`,
        json: true
    }
    let res = await rp(options)

    //   本地存储 对应用户的读者证号
    let openid = param.openid

    let elibuser = await ElibUser.findOneAndUpdate({
            openid: openid
        }, {
            $set: {
                rdrid: res.rows[0].id || '未获取读者ID',
                rdrno: res.rows[0].rdrno || '未获取读者证号码',
                status: res.rows[0].status,
                rdrtype: res.rows[0].rdrtype,
                libcode: res.rows[0].libcode,
                createdate: res.rows[0].createdate,
                enddate: res.rows[0].enddate,
            }
        }, {
            new: true
        }

    )
    return res
}

//解绑

exports.unBindInfo = async (param) => {
    //解绑
    let token = await updateToken() //elib授权token
    let openid = param.openid
    let elibuser = await ElibUser.findOne({
        openid: openid
    })
    let rdrid = elibuser.rdrid
    let unbind_url = `reader/unbindOpenid.do?id=${rdrid}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${unbind_url}`,
        json: true
    }
    let res = await rp(options)

    // 删除本地关联的读者证号 读者ID
    elibuser.rdrno = null
    elibuser.rdrid = null
    elibuser.qr_rdrno = null
    elibuser = await elibuser.save()

    return res
}

//读者登录验证

exports.rdLogin = async (param) => {
    let currentToken = await updateToken() //elib授权token
    let loginUrl = `reader/checkReader.do?rdrno=${param.rdrno}&password=${param.pwd}&token=${currentToken}`
    let options = {
        uri: `${cfg.elib.baseurl}${loginUrl}`,
        json: true
    }
    let res = await rp(options)
    return res

}
//根据读者账号 获取读者基本信息 包括读者ID
exports.getRdrID = async (param) => {
    let currentToken = await updateToken() //elib授权token
    let getRdrInfo = `reader/getReaderBaseInfo.do?rdrno=${param.rdrno}&token=${currentToken}`
    let options = {
        uri: `${cfg.elib.baseurl}${getRdrInfo}`,
        json: true
    }
    let res = await rp(options)

    return res
}
//获取读者其他信息/资料
exports.getUserOthInfo = async (param) => {
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let rdrno = elibuser.rdrno
    let token = await updateToken()
    let uri = `reader/getReaderExtendInfo.do?rdrno=${rdrno}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${uri}`,
        json: true
    }
    let res = await rp(options)
    return res
}
//获取读者当前借阅
exports.getUserBorrow = async (param) => {
    let token = await updateToken()
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let rdrno = elibuser.rdrno
    let uri = `holding/listRdrCurLoan.do?rdrno=${rdrno}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${uri}`,
        json: true
    }
    let res = await rp(options)
    return res
}

// 建议留言
exports.suggestion = async (param) => {
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })


    let suggestion = new Suggestion({
        up_author: {
            openid: param.openid,
            nickname: elibuser.nickname,
            avatar: elibuser.avatar,
            author_id: elibuser._id
        },
        content: param.content,
        reply: null
    })

    let res = await suggestion.save()
    return {
        success: true
    }
}

//查询读者的建议留言
exports.getSuggestion = async (param) => {
    console.log('查询读者的建议留言')
    console.log(param)
    let res = await Suggestion.find({
        "up_author.openid": param.openid
    }).sort({
        'meta': -1
    })
    console.log(res)

    return res

}

//查询读者预约信息

exports.reserinfo = async (param) => {
    let token = await updateToken()
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let rdrid = elibuser.rdrid
    if (!rdrid) {
        return false
    }

    let reserinfo_url = `reserve/listRdrCurReserves.do?rdrid=${rdrid}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${reserinfo_url}`,
        json: true
    }
    let res = await rp(options)
    return res
}

//财经 查询
exports.payment = async (param) => {
    let token = await updateToken()
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let rdrid = elibuser.rdrid
    if (!rdrid) {
        // 未绑定 /登录
        return {
            message: '未绑定读者证号'
        }
    }
    let payment_url = `curfine/listRdrCurFine.do?token=${token}&rdrid=${rdrid}`
    let options = {
        uri: `${cfg.elib.baseurl}${payment_url}`,
        json: true
    }
    let res = await rp(options)
    console.log(options.uri)
    return res
}
// 财经支付I(微信支付完成 发起此接口)
exports.payRes = async (param) => {
    console.log(param)
    let token = await updateToken()
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let rdrid = elibuser.rdrid

    if (!rdrid) {
        // 未绑定 /登录
        return {
            message: '未绑定读者证号'
        }
    }

    let parentids = param.parentids
    let payway = param.payway

    let payres_url = `curfine/payFine.do?token=${token}&parentids=${parentids}&payway=${payway}`
    let options = {
        uri: `${cfg.elib.baseurl}${payres_url}`,
        json: true
    }
    let res = await rp(options)
    console.log(options.uri)
    return res
}
// 用户所有信息

exports.allUserInfo = async (param) => {
    let token = await updateToken()
    console.log('用户所有信息')
    // 获取基本参数 
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    // console.log(elibuser.rdrno)
    if (!elibuser.rdrid || !elibuser.rdrno) {
        let all_res = {
            base: {
                nickname: elibuser.nickname,
                avatar: elibuser.avatar,
                rdrno: elibuser.rdrno,
                qr_rdrno: elibuser.qr_rdrno,
                status: elibuser.status,
                rdrtype: elibuser.rdrtype,
                libcode: elibuser.libcode,
                createdate: elibuser.createdate,
                enddate: elibuser.enddate
            },
            other: null,
            reserinfo: null,
            borrowed: null
        }
        return all_res
    }
    let rdrno = elibuser.rdrno

    // 额外信息
    let other_url = `reader/getReaderExtendInfo.do?rdrno=${rdrno}&token=${token}`
    let other_options = {
        uri: `${cfg.elib.baseurl}${other_url}`,
        json: true
    }
    let other_res = await rp(other_options)
    console.log('额外信息')
    let other_res_item = {
        deposit: other_res.rows[0].deposit, //押金
        debt: other_res.rows[0].debt, //欠款
        maxloan: other_res.rows[0].maxloan, //最大借阅
        curloan: other_res.rows[0].curloan //当前借阅
    }
    // 预约信息

    let reserinfo_url = `reserve/listRdrCurReserves.do?rdrid=${elibuser.rdrid}&token=${token}`
    let reserinfo_options = {
        uri: `${cfg.elib.baseurl}${reserinfo_url}`,
        json: true
    }
    let reserinfo_res = await rp(reserinfo_options)
    let reserinfo_list = []
    for (let i = 0; i < reserinfo_res.rows.length; i++) {
        reserinfo_list[reserinfo_list.length] = reserinfo_res.rows[i]
    }

    // 当前借阅

    let cur_borrow_url = `holding/listRdrCurLoan.do?rdrno=${rdrno}&token=${token}`
    let borrow_options = {
        uri: `${cfg.elib.baseurl}${cur_borrow_url}`,
        json: true
    }
    let cur_borrow_res = await rp(borrow_options)
    let borrowed_list = []
    let barcodes = []

    for (let j = 0; j < cur_borrow_res.rows.length; j++) {
        borrowed_list[borrowed_list.length] = cur_borrow_res.rows[j]
        barcodes[barcodes.length] = cur_borrow_res.rows[j].barcode
    }
    // 存储 借阅图书的barcode
    await ElibUser.findOneAndUpdate({
        openid: param.openid
    }, {
        $set: {
            barcodes: barcodes
        }
    }, {
        new: true
    })
    // ------------
    let all_res = {
        base: {
            nickname: elibuser.nickname,
            avatar: elibuser.avatar,
            rdrno: elibuser.rdrno,
            qr_rdrno: elibuser.qr_rdrno,
            status: elibuser.status,
            rdrtype: elibuser.rdrtype,
            libcode: elibuser.libcode,
            createdate: elibuser.createdate,
            enddate: elibuser.enddate
        },
        other: other_res_item,
        reserinfo: reserinfo_list,

        borrowed: borrowed_list
    }
    return all_res
}
// 续借
exports.renewFn = async (param) => {
    let token = await updateToken()
    let renew_url = `circulation/renewBook.do?barcode=${param.barcode}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${renew_url}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    return res
}
// 语音续借
exports.yyRenewFn = async (param) => {
    console.log('循环续借操作')
    let token = await updateToken()

    console.log('语音续借所有图书')
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    // 查询续借的列表
    let cur_borrow_url = `holding/listRdrCurLoan.do?rdrno=${elibuser.rdrno}&token=${token}`
    let borrow_options = {
        uri: `${cfg.elib.baseurl}${cur_borrow_url}`,
        json: true
    }
    let cur_borrow_res = await rp(borrow_options)
    let barcodes = []

    for (let j = 0; j < cur_borrow_res.rows.length; j++) {
        barcodes[barcodes.length] = cur_borrow_res.rows[j].barcode
    }

    // 循环续借操作
    let yyres = []
    for (let i = 0; i < barcodes.length; i++) {
        let renew_url = `circulation/renewBook.do?barcode=${barcodes[i]}&token=${token}`
        let options = {
            uri: `${cfg.elib.baseurl}${renew_url}`,
            json: true
        }
        let res = await rp(options)
        let item = {
            title: res.rows[0].title,
            status: res.status
        }
        yyres[yyres.length] = item
    }
    // 
    return yyres

}
// 取消预约
exports.cancleAppt = async (param) => {
    let token = await updateToken()

    let cu_uri = `reserve/cancelReserve.do?id=${param.id}&token=${token}`

    let options = {
        uri: `${cfg.elib.baseurl}${cu_uri}`,
        json: true
    }
    let res = rp(options)

    return res
}
//图书管公告
exports.libraryNotice = async (param) => {

    let token = await updateToken()

    let currentWallToken = await wallToken()

    console.log(currentWallToken)
    let infoUrl = `wall/spider/qy?type=${param.type}&page=${param.page}&size=${param.size}`
    let options = {
        uri: `${cfg.elib.baseurl}${infoUrl}`,
        json: true,
        headers: {
            Authorization: currentWallToken
        }
    }
    console.log(options.uri)
    let res = await rp(options)
    return res
}
//修改密码
exports.changePwd = async (param) => {
    let token = await updateToken()
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    let changePwdUri = `reader/modifyPassword.do?id=${elibuser.rdrid}&password=${param.password}&token=${token}`
    let options = {
        uri: `${cfg.elib.baseurl}${changePwdUri}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    return res
}
//获取高德地图 POI ID 用于高德导航
exports.getAMapID = async (param) => {
    let POI_URL = 'https://restapi.amap.com/v3/place/text?'
    let key = '90160333b13a3bd0bf64e9dba1881cfa'
    let extensions = 'all'
    let keywords = param.keywords
    let keyword = ''
    let uri = ''
    let options = {
        uri: uri,
        json: true
    }
    let res_list = []
    for (let i = 0; i < keywords.length; i++) {
        keyword = encodeURI(keywords[i])
        options.uri = `${POI_URL}key=${key}&keywords=${keyword}&extensions=${extensions}`
        let res = await rp(options)
        let id = res.pois[0].id
        let item_url = `https://ditu.amap.com/place/${id}`
        res_list[res_list.length] = item_url
    }

    return res_list
}

//检测用户是否绑定 读者证号
exports.testAuth = async (param) => {
    let openid = param.openid
    console.log(param)
    console.log('检测用户是否绑定 读者证号' + openid)
    let elibuser = await ElibUser.findOne({
        openid: openid
    })
    if (!elibuser || !elibuser.rdrno || !elibuser.rdrid) {
        // console.log('elibuser.rdrno:  ' + elibuser.rdrno)
        // console.log("elibuser.rdrid: " + elibuser.rdrid)
        return {
            status: false,
            rdrno: '',
            rdrid: ''
        }
    } else {
        return {
            status: true,
            rdrno: elibuser.rdrno,
            rdrid: elibuser.rdrid
        }
    }

}

//校验用户是否登录过
exports.isLogin = async (param) => {
    console.log('校验用户是否登录过')
    let elibuser = await ElibUser.findOne({
        openid: param.openid
    })
    return {
        userinfo: elibuser
    }
}


// 设置第三方应用


exports.setServer = async (param) => {
    console.log(param)


    let otherApp = await OtherApp.setApp(param)
    return otherApp
}

//获取配置的第三方应用
exports.getApps = async (param) => {
    let apps = await OtherApp.getApps()
    return apps
}

//删除某个第三方应用

exports.delApp = async (param) => {
    let res = await OtherApp.delApp(param)
    return res
}

exports.uploadfile = async (param) => {
    return {
        success: 'ok'
    }
}


//七牛云相关
const qiniu = require('qiniu')

// 创建上传凭证
const accessKey = '_VXPrWO7xy6zC_UvuFpc7CKAhFsZLeq5NDMVnv4T'
const secretKey = 'er7bUaAkOFuQ7cgZAkIgAzHdPZZlNj3IdVoEcd00'
const mac = new qiniu.auth.digest.Mac(accessKey, secretKey)


exports.uploadToken = async () => {
    let token = await QINIU.getUploadToken()
    if (token) {
        const now = new Date().getTime()
        let expiresIn = token.expires_in
        if (now < expiresIn) {
            return token.token
        } else {
            let options = {
                scope: 'rfid-lp',
                expires: 7200
            }
            let putPolicy = new qiniu.rs.PutPolicy(options)
            let uploadToken = putPolicy.uploadToken(mac)
            console.log(uploadToken)

            // 存储
            //存储到库
            const expiresIn = now + (options.expires - 20) * 1000
            let token_data = {
                uploadtoken: uploadToken,
                expires_in: expiresIn
            }
            let save_qiniu_token = await QINIU.saveUploadToken(token_data)
            console.log(save_qiniu_token)

            return uploadToken
        }
    } else {
        let options = {
            scope: 'rfid-lp',
            expires: 7200
        }
        let putPolicy = new qiniu.rs.PutPolicy(options)
        let uploadToken = putPolicy.uploadToken(mac)
        console.log(uploadToken)
        //存储到库
        const now = new Date().getTime()
        const expiresIn = now + (options.expires - 20) * 1000
        let token_data = {
            uploadtoken: uploadToken,
            expires_in: expiresIn

        }
        let save_qiniu_token = await QINIU.saveUploadToken(token_data)
        console.log(save_qiniu_token)
        return uploadToken
    }
}

exports.setCarousel = async (param) => {

    let res = await Carousel.setCarousel(param)

    return res
}
exports.delCarousel = async (param) => {
    let res = await Carousel.delCarousel(param)
    return res
}
exports.getCarousel = async () => {
    console.log('获取轮播 api')
    let res = await Carousel.getCarousel()
    console.log(res)
    return res
}


exports.allComment = async () => {

    let res = await Suggestion.find().sort({
        'meta': -1
    }).limit(100)
    return res
}
// 文化馆相关
exports.userLogin = async (params) => {
    console.log(params)
    let options = {
        uri: `http://jsdz7.mynetgear.com:8883/activity/libcirreader/checklogin?rdrno=${params.rdrno}&password=${params.password}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)

    /* 本地保存用户账户信息 */
    let openid = params.openid
    let elibuser = await ElibUser.findOneAndUpdate({
        openid: openid
    }, {
        $set: {
            rdrno: params.rdrno || '未获取读者证号码',
            rdrpwd: params.password,
        }
    }, {
        new: true
    })
    console.log(elibuser)
    return res

}