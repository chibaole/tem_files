const mongoose = require('mongoose')
const Schema = mongoose.Schema

const WHGConfigSchema = new Schema({

    // 公众号
    wechat: {
        appID: String,
        appSecret: String,
        token: String,
        mch_id: String,
        mch_key: String,
        redirect_url: String
    },
    // elib部分

    elib: {
        account: String,
        password: String,
        client_id: String,
        baseurl: String,
        other_url: String,
    },

    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

WHGConfigSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = this.meta.updatedAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

WHGConfigSchema.statics = {
    async getConfig() {
        let config = await this.findOne({})
        if (!config) {
            config = {}
            return {
                msg: '没有任何内容',
                code: 0,
            }
        }
        return config
    },
    async setConfig(param) {
        console.log(param)
        let config = await this.findOne({})
        if (config) {
            console.log('后台已有系统配置')
            config.wechat = {
                appID: param.wechat.appID,
                appSecret: param.wechat.appSecret,
                token: param.wechat.token,
                mch_id: param.wechat.mch_id,
                mch_key: param.wechat.mch_key,
                redirect_url: param.wechat.redirect_url
            }
            config.elib = {
                account: param.elib.account,
                password: param.elib.password,
                client_id: param.elib.client_id,
                baseurl: param.elib.baseurl,
                other_url: param.elib.other_url,

            }

        } else {
            console.log('后台没有配置')
            config = new WHGConfig({
                wechat: {
                    appID: param.wechat.appID,
                    appSecret: param.wechat.appSecret,
                    token: param.wechat.token,
                    mch_id: param.wechat.mch_id,
                    mch_key: param.wechat.mch_key
                },

                elib: {
                    account: param.elib.account,
                    password: param.elib.password,
                    client_id: param.elib.client_id,
                    baseurl: param.elib_baseurl,
                    other_url: param.elib.other_url,
                }
            })
        }
        await config.save()
        return config
    },
    async getAppid() {
        const config = await this.findOne({

        })

        if (config && config.wechat.appID) {
            config.wechat.appID = config.wechat.appID
        }
        return config.wechat.appID
    },
    async getAppSecret() {
        const config = await this.findOne({

        })
        if (config && config.wechat.appSecret) {
            config.wechat.appSecret = config.wechat.appSecret
        }
        return config.wechat.appSecret
    },
    async getToken() {
        const config = await this.findOne({

        })

        if (config && config.wechat.token) {
            config.wechat.token = config.wechat.token
        }
        return config.wechat.token
    },

}

const WHGConfig = mongoose.model('WHGConfig', WHGConfigSchema)