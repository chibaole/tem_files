/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-06 16:33:22
 * @Description: file content
 */
const mongoose = require('mongoose')

const Schema = mongoose.Schema

const ElibUserSchema = new Schema({
  openid: String,
  rdrno:String,
  rdrid:String,
  rdrpwd:String,
  unionid: String,
  nickname: String,
  address: String,
  province: String,
  country: String,
  city: String,
  gender: String,
  avatar:String,
  qr_rdrno:String,
  status:String,
  rdrtype:String,
  libcode:String,
  createdate:String,
  enddate:String,
  barcodes:Array,
  from:String,
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})



// 中间件
ElibUserSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

mongoose.model('ElibUser', ElibUserSchema)
