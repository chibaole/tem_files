/*
 * @Author: 刘攀
 * @Date: 2019-11-15 11:23:14
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-12-02 16:11:09
 * @Description: file content
 */
const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ConfigSchema = new Schema({
    name: String,
    title: String,
    redirect_uri: String,
    // 公众号
    wechat: {
        appID: String,
        appSecret: String,
        token: String,
        mch_id:String,
        key:String
    },
    // elib部分

    elib: {
        account: String,
        password: String,
        client_id: String,
        baseurl: String,
        other_url: String,
        autordrno:String,
        rdrtype:String
    },

    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

ConfigSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = this.meta.updatedAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

ConfigSchema.statics = {
    async getConfig() {
        let config = await this.findOne({
            name: 'config'
        })
        if (!config) {
            config = {}
        }
        return config
    },
    async setConfig(param) {
        console.log(param)
        let config = await this.findOne({
            name: 'config'
        })
        if (config) {
            config.title = param.title,
            config.redirect_uri = param.redirect_uri,
                config.wechat = {
                    appID: param.AppID,
                    appSecret: param.AppSecret,
                    token: param.Token,
                    mch_id:param.mch_id,
                    key:param.key
                }
            config.elib = {
                account: param.elib_account,
                password: param.elib_password,
                client_id: param.elib_client_id,
                baseurl: param.elib_baseurl,
                other_url: param.other_url,
                autordrno:param.autordrno,
                rdrtype:param.rdrtype
            }

        } else {
            config = new Config({
                name: 'config',
                title: param.title ||'',
                redirect_uri: param.redirect_uri || '',

                wechat: {
                    appID: param.AppID,
                    appSecret: param.AppSecret,
                    token: param.Token,
                    mch_id:param.mch_id,
                    key:param.key
                },

                elib: {
                    account: param.elib_account,
                    password: param.elib_password,
                    client_id: param.elib_client_id,
                    baseurl: param.elib_baseurl,
                    other_url: param.other_url,
                    autordrno:param.autordrno,
                    rdrtype:param.rdrtype

                }
            })
        }
        await config.save()
        return config
    },
    async getAppid(){
        const config = await this.findOne({
            name: 'config'
        })
     
        if(config&&config.wechat.appID){
            config.wechat.appID = config.wechat.appID
        }
        return config.wechat.appID
    },
    async getAppSecret(){
        const config = await this.findOne({
            name: 'config'
        })
        if(config&&config.wechat.appSecret){
            config.wechat.appSecret = config.wechat.appSecret
        }
        return config.wechat.appSecret
    },
    async getToken(){
        const config = await this.findOne({
            name: 'config'
        })
     
        if(config&&config.wechat.token){
            config.wechat.token = config.wechat.token
        }
        return config.wechat.token
    }

}

const Config = mongoose.model('Config', ConfigSchema)