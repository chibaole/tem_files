/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-12-02 17:43:22
 * @Description: file content
 */

module.exports = {
  button: [{
      type: "view",
      name: "微信服务大厅",
      url: "http://liupan.js-shrfid.com"
    },
    {
      name: '导航',

      sub_button: [{

        name: '导航',
        type: 'view',
        url: 'http://liupan.js-shrfid.com/AMapID'
      }]
    },
    {
      name: '服务指南',
      sub_button: [{
          name: '本馆介绍',
          type: 'click',
          key: 'bg_js'
        }, {
          name: '办证指南',
          type: 'click',
          key: 'bz_zn'
        }, {
          name: '网点分布',
          type: 'view',
          url: 'http://liupan.js-shrfid.com/AMapID'
        },
        {
          name: '馆内公告',
          type: 'view',
          url: 'http://liupan.js-shrfid.com/about'
        }
      ]
    }
  ]
}