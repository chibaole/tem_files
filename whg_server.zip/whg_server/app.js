/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-22 17:40:45
 * @Description: file content
 */
const Koa = require('koa')
const { resolve } = require('path')
const bodyParser = require('koa-bodyparser')
const serve = require('koa-static')
const Router = require('koa-router')
const config = require('./config/config')


const { initSchemas, connect } = require('./app/database/init')
var cors = require('koa2-cors');

;(async () => {

  await connect(config.db)

  initSchemas()
  // 生成服务器实例
  const app = new Koa()
  const router = new Router()
  const views = require('koa-views')

  app.keys = ['wechat_server']
  app.use(bodyParser())
  app.use(serve(resolve(__dirname, '../public')))
  app.use(cors());

  require('./router/index')(router)

  app.use(router.routes()).use(router.allowedMethods())

  app.listen(3030)
  console.log('Listen: ' + 3030)
})()



