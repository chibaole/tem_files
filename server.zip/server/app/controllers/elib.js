/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-20 00:37:16
 * @Description: file content
 */
const fs = require('fs')
const path = require('path');
// 数据库操作
const mongoose = require('mongoose')
const _ = require('lodash')
const api = require('../api')

//武大的 获取读者信息
exports.wd_getUserInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_getUserInfo(param)
    ctx.body = res
}

// 武大读者验证
exports.wd_BorValid = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_BorValid(param)
    ctx.body = res
}

//读者解绑
exports.wd_unbind = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_unbind(param)
    ctx.body = res
}

//书目检索
exports.wx_findAll = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wx_findAll(param)
    ctx.body = res
}

exports.wd_sort_set = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_sort_set(param)
    ctx.body = res
}

exports.wd_present = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_present(param)
    ctx.body = res
}

// 武大 图书查询
exports.wd_findBook = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_findBook(param)
    ctx.body = res
}

//wd 预约
exports.wd_holdBook = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_holdBook(param)
    ctx.body = res
}

//取消预约
exports.wd_cancelHold = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_cancelHold(param)
    ctx.body = res
}

exports.wd_renew = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_renew(param)
    ctx.body = res
}

//预约列表
exports.wd_holdList = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_holdList(param)
    ctx.body = res
}

exports.wd_loanHistory = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_loanHistory(param)
    ctx.body = res
}

//新书推荐
exports.wd_newbooklist = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_newbooklist(param)
    ctx.body = res
}

//借阅排行
exports.wd_topBook = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wd_topBook(param)
    ctx.body = res
}

//图书封面
exports.wx_bookCover = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.wx_bookCover(param)
    ctx.body = res
}

exports.get_wd_News = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.get_wd_News(param)
    ctx.body = res
}

exports.getNewsDetail = async (ctx, next) => {
    let param = ctx.query
    let res = await api.spilder.getNewsDetail(param)
    ctx.body = res
}
// ----------------------------原有的的control
//根据字段 检索图书
exports.searchBook = async (ctx, next) => {
    let param = ctx.query
    const books = await api.elib.searchBookBykeyword(param)
    ctx.body = books
}

//馆藏信息
exports.holding = async (ctx, next) => {
    let param = ctx.query
    const res = await api.elib.holding(param)
    ctx.body = res
}

// 馆藏检索
exports.listHoldings = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.listHoldings(param)
    ctx.body = res
}

// 预约某个馆藏图书
exports.reservation = async (ctx, next) => {
    let param = ctx.query
    const res = await api.elib.reservation(param)
    ctx.body = res
}

//文献借阅榜
exports.billboard = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.billboard(param)
    ctx.body = res
}

//建议 投诉
exports.suggestion = async (ctx, next) => {
    let param = ctx.request.body.data //获取post提交的数据 字符串
    let res = await api.elib.suggestion(param)
    ctx.body = res
}

//查询读者 建议留言
exports.getSuggestion = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getSuggestion(param)
    ctx.body = res
}

// 办证 新增网上读者
exports.applyID = async (ctx, next) => {
    let postParam = ctx.request.body.data //获取post提交的数据 字符串
    let res = await api.elib.applyID(postParam)
    ctx.body = res
}

// 更新用户信息 增加 读者ID 读者证号
exports.userUpdate = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.updateUser(param)
    ctx.body = res
}

// 获取elib的系统信息
exports.systemInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.systemInfo(param)
    ctx.body = res
}

//查询绑定信息
exports.getBindInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getBindInfo(param)
    ctx.body = res
}

//绑定读者账号
exports.bindWechatID = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.bindWechatID(param)
    ctx.body = res
}

exports.unBindInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.unBindInfo(param)
    ctx.body = res
}

exports.rdLogin = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.rdLogin(param)
    ctx.body = res
}

//根据读者的账号  获取读者id  便于绑定 微信用户
exports.getRdrID = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getRdrID(param)
    ctx.body = res
}

// 预约图书
exports.reservation = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.reservation(param)
    ctx.body = res
}

// 获取读者更多信息
exports.getUserOthInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getUserOthInfo(param)
    ctx.body = res
}

//获取读者当前借阅列表
exports.getUserBorrow = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getUserBorrow(param)
    ctx.body = res
}

//读者预约信息
exports.reserinfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.reserinfo(param)
    ctx.body = res
}

//用户所有数据
exports.allUserInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.allUserInfo(param)
    ctx.body = res
}

// 续借
exports.renewFn = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.renewFn(param)
    ctx.body = res
}
exports.allRenew = async (ctx, next) => {
    //('循环续借操作 controller')
    let param = ctx.query
    let res = await api.elib.yyRenewFn(param)
    ctx.body = res
}

// 读者财经信息查询
exports.payment = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.payment(param)
    ctx.body = res
}
//财经 付款

exports.payRes = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.payRes(param)
    ctx.body = res
}
//取消预约
exports.cancleAppt = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.cancleAppt(param)
    ctx.body = res
}

exports.libraryNotice = async (ctx, next) => {
    let param = ctx.query || {}
    let res = await api.elib.libraryNotice(param)
    ctx.body = res
}

exports.changePwd = async (ctx, next) => {
    let param = ctx.request.body
    let res = await api.elib.changePwd(param)
    ctx.body = res
}

exports.getAMapID = async (ctx, next) => {
    let param = ctx.request.body
    let res = await api.elib.getAMapID(param)
    ctx.body = res
}

exports.testAuth = async (ctx, next) => {
    //('检测用户绑定')
    let param = ctx.query
    let res = await api.elib.testAuth(param)
    ctx.body = res
}

exports.isLogin = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.isLogin(param)
    ctx.body = res
}

exports.setServer = async (ctx, next) => {
    let param = ctx.request.body
    let res = await api.elib.setServer(param)
    ctx.body = res
}

exports.getApps = async (ctx, next) => {
    let res = await api.elib.getApps()
    ctx.body = res
}

exports.delApp = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.delApp(param)
    ctx.body = res
}

exports.uploadToken = async (ctx, next) => {
    console.log('uploadToken')
    let token = await api.elib.uploadToken()
    ctx.body = token
}
// NewSetCarousel
// exports.setCarousel = async (ctx, next) => {
//     let param = ctx.request.body
//     let res = await api.elib.setCarousel(param)
//     ctx.body = res
// }
exports.setCarousel = async (ctx, next) => {
    let params = ctx.request.body
    console.log(params)
    let res = await api.elib.NewSetCarousel(params)
    ctx.body = res
}
exports.delCarousel = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.delCarousel(param)
    ctx.body = res
}
exports.getCarousel = async (ctx, next) => {
    let res = await api.elib.getCarousel()
    ctx.body = res
}

// wechat app
exports.wxlogin = async (ctx, next) => {
    let params = ctx.query
    let res = await api.elib.wxlogin(params)
    ctx.body = res
}

exports.uploadfile = async (ctx, next) => {
    let param = ctx.request.body.fields;
    // console.log(ctx.request.body)
    console.log(param)

    let res = await api.elib.uploadfile(param)
    ctx.body = res
}

//2020 新增武大借书

exports.wd_loan = async(ctx,next)=>{
    let params = ctx.query
    let res = await api.elib.wd_loan(params)
    ctx.body = res
}

exports.test = async (ctx,next) =>{
    console.log('test')
    const Userinfo = mongoose.model('Config')
    // let obj = await Userinfo.findOne({'nickname':'刘攀'})
    let elibuser = await Userinfo.findOne({
        name: 'config'
    })
    console.log(elibuser)
    let res = elibuser
    ctx.body = res
}