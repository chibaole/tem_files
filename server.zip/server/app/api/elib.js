/*
 * @Author: 刘攀
 * @Date: 2019-10-15 14:57:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-21 15:48:47
 * @Description: file content
 */
const mongoose = require('mongoose')
const Suggestion = mongoose.model('Suggestion')
const rp = require('request-promise')
const _ = require('lodash')
const WdBoy = mongoose.model('WdBoy')
const Cfg = mongoose.model('Config')
const OtherApp = mongoose.model('OtherApp')
const Carousel = mongoose.model('Carousel')
const NewsData = mongoose.model('NewsData')
const QINIU = mongoose.model('QINIU')
const config = require('../../config/config')
const xml2js = require('xml2js');
const fs = require('fs')
const path = require('path');
const parseXml = (xml) => {
    let {
        parseString
    } = xml2js;
    let res;
    parseString(xml, {
        trim: true,
        explicitArray: false
    }, function (err, result) {
        res = result;
    });
    return res;
}
//关注即持久化 关注的用户  
exports.saveWdBoy = async (message) => {
    //根据open ID 获取 用户的微信信息
    let mp = require('../../wechat/index')
    let client = mp.getWechat()
    let openid = message.FromUserName
    let userInfo = await client.handle('getUserInfo', openid)
    let wd_boy = await WdBoy.findOne({
        openid: openid
    }) //查找已存在的用户
    if (!wd_boy) {
        let boyData = {
            openid: userInfo.openid,
            unionid: userInfo.unionid || null,
            nickname: userInfo.nickname,
            province: userInfo.province,
            country: userInfo.country,
            city: userInfo.city,
            gender: userInfo.gender || userInfo.sex,
            avatar: userInfo.headimgurl,
            //下为需要 elib账号绑定获取数据
            bor_id: '',
            wd_id: '',
            status: '',
            library: '',
            from: 'subscribe'
        }
        wd_boy = new WdBoy(boyData)
        wd_boy = await wd_boy.save()
    } else {
        wd_boy.avatar = wd_boy.headimgurl
        wd_boy.from = 'subscribe'
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}
//前端 获取code 然后保存 用户数据
exports.saveWdBoyBycode = async (userData) => {
    let query = {
        openid: userData.openid
    }
    let wd_boy = await WdBoy.findOne(query)
    console.log(wd_boy)
    console.log('-----')
    console.log(userData)
    if (!wd_boy) {
        wd_boy = new WdBoy({
            openid: userData.openid,
            unionid: userData.unionid || null,
            nickname: userData.nickname,
            province: userData.province,
            country: userData.country,
            city: userData.city,
            gender: userData.gender || userData.sex,
            avatar: userData.headimgurl || '',
            //下为需要 elib账号绑定获取数据
            bor_id: '',
            wd_id: '',
            status: '',
            library: '',
            from: 'front-end'
        })
        wd_boy = await wd_boy.save()
    } else {
        wd_boy.nickname = userData.nickname
        wd_boy.province = userData.province
        wd_boy.country = userData.country
        wd_boy.city = userData.city
        wd_boy.avatar = userData.headimgurl
        await wd_boy.save()

    }
    return wd_boy
}
//取消关注删除 elibuser相关用户  
exports.delWdBoy = async (message) => {
    //删除本openid 的elibuser用户数据
    let mp = require('../../wechat/index')
    let openid = message.FromUserName
    await WdBoy.remove({
        openid: openid
    }, function (error) {
        if (error) {
            console.error(error);
        } else {
            console.error("用户删除成功")
        }
    })
    //删除后用户
    let wd_boy = await WdBoy.findOne({
        openid: openid
    }, function (error, doc) {

    })
}
exports.updateWdBoy = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = '读者证的id'
        wd_boy.wd_id = ''
        wd_boy = new WdBoy(wd_boy)
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}

//单册信息 、预约列表！、预约请求！、读者认证！、 新书通报！过期列表、借阅历史、获取馆藏信息？？ 、借阅排行、图书封面
// 权限管理 获取session
const wx_login = async () => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    let url = `?op=login&user_name=${x_service.user_name}&user_password=${x_service.user_password}&library=${x_service.library}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn.login['session-id']
}

//读者认证  ----- 
exports.wd_BorValid = async (param) => {
    let bor_id = param.bor_id
    let verification = param.verification
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    let url = `?user_name=${x_service.user_name}&user_password=${x_service.user_password}&op=bor_auth&bor_id=${bor_id}&verification=${verification}&library=${x_service.library}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    //获取读者二维码
    const qr_options = {
        uri: `http://apis.juhe.cn/qrcode/api?key=095ba999ef9f2a061fbfd32dff2fa30f&type=1&fgcolor=000000&w=150&m=5&text=${param.data}`,
        json: false
    }
    const data = await rp(qr_options)
    let data_json = JSON.parse(data)
    let qr_bor_id = data_json.result.base64_image
    //更新存储的读者信息
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = bor_id
        wd_boy.wd_id = resJspn['bor-auth']['z303']['z303-id']
        wd_boy.library = resJspn['bor-auth']['z303']['z303-user-library']
        wd_boy.qr_borid = qr_bor_id
        wd_boy = new WdBoy(wd_boy)
        wd_boy = await wd_boy.save()
    }
    return resJspn
}

//读者绑定微信号信息
exports.getBindInfo = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    return wd_boy
}

//读者解绑
exports.wd_unbind = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    if (wd_boy) {
        wd_boy.bor_id = ''
        wd_boy.wd_id = ''
        wd_boy = await wd_boy.save()
    }
    return wd_boy
}

//读者信息获取 ----- 可用 需要参数  library 
exports.wd_getUserInfo = async (param) => {
    let openid = param.openid
    console.log('openid ---' + openid)
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    console.log(wd_boy)
    let bor_id = wd_boy.bor_id
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    // http://218.197.145.4:8991/X?op=bor_info&bor_id=XTB001&format=1&cash=O&&loans=Y&hold=Y&translate=N&user_name=RFID_X&user_password=RFID_X
    let url = `?op=bor_info&bor_id=${bor_id}&verification=123&library=${x_service.library}&format=1&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res)
    return resJspn
}

exports.isLogin = async (param) => {
    let openid = param.openid
    if(openid){ 
        console.log('openid ---' + openid)
        let wd_boy = await WdBoy.findOne({
            openid: openid
        })
        return wd_boy
    }else{
        return false
    }
   
}

//检索图书资源
exports.wx_findAll = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt) //x_service 的配置 包括账号 密码 host library 

    let base = x_service.base
    let request_wd = param.keyword
    let keyword = encodeURI(request_wd);
    let code = param.filedword
    let url = `?op=find&code=${code}&request=${keyword}&base=${base}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 显示图书资源
exports.wd_present = async (param) => {

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)

    let set_entry = param.set_entry || '000000001-000000010'
    let set_number = param.set_number
    let url = `?op=present&base=${x_service.base}&set_number=${set_number}&set_entry=${set_entry}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 单册信息
exports.wd_findBook = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)

    let doc_number = param.doc_number || "001246867"
    let url = `?op=item_data_nlc&doc_number=${doc_number}&base=${x_service.base}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//预约列表
exports.wd_holdList = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)
    let url = `?op=hold_list`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//预约请求
exports.wd_holdBook = async (param) => {

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)

    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_id = wd_boy.wd_id || wd_boy.bor_id
    let item_barcode = param.item_barcode
    let url = `?op=hold_req_nlc&id=${wd_id}&item_barcode=${item_barcode}&library=${x_service.library}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    //(options.uri)
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//取消预约
exports.wd_cancelHold = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_id = wd_boy.wd_id || wd_boy.bor_id
    let doc_number = param.doc_number
    let item_sequence = param.item_sequence
    let sequence = param.sequence
    let url = `?op=hold-req-cancel&doc_number=${doc_number}&item_sequence=${item_sequence}&sequence=${sequence}&library=${x_service.library}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//续借图书
exports.wd_renew = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)

    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let wd_bor_id = wd_boy.wd_id || wd_boy.bor_id
    let doc_number = param.doc_number
    let item_sequence = param.item_sequence
    let url = `?op=renew&doc_number=${doc_number}&item_sequence=${item_sequence}&bor_id=${wd_bor_id}&library=${x_service.library}&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 建议留言
exports.suggestion = async (param) => {
    let openid = param.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    let suggestion = new Suggestion({
        up_author: {
            openid: openid,
            nickname: wd_boy.nickname,
            avatar: wd_boy.avatar,
            author_id: wd_boy._id
        },
        content: param.content,
        reply: null
    })
    let res = await suggestion.save()
    return {
        success: true
    }
}

//查询读者的建议留言
exports.getSuggestion = async (param) => {
    let res = await Suggestion.find({
        "up_author.openid": param.openid
    }).sort({
        'meta': -1
    })
    return res
}

exports.wd_loanHistory = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)

    let url = `?op=loan_history&bor_id=xtb001&bor_id_type=00&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost}${url}&user_name=${x_service.user_name}&user_password=${x_service.user_password}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

// 新书通报
exports.wd_newbooklist = async (param) => {
    // http://opactest.lib.whu.edu.cn/cgi-bin/newbook_xml.cgi?&library=whu01&shelf_date_from=180&max_entry=100

    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)

    let url = `newbook_xml.cgi?library=${x_service.base}&shelf_date_from=180&max_entry=100&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//借阅排行
exports.wd_topBook = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)
    // http://opactest.lib.whu.edu.cn/cgi-bin/toploan_xml.cgi?&library=whu01&order_key=toptenm&max_entry=100
    let url = `toploan_xml.cgi?&library=${param.library}&order_key=toptenm&max_entry=20&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    //(options.uri)
    let res = await rp(options)
    let resJspn = parseXml(res);
    return resJspn
}

//图书封面
exports.wx_bookCover = async (param) => {
    let opt = {
        name: 'wdelib'
    }
    let x_service = await Cfg.get_param_info(opt)
    //(x_service)
    let url = `acover.cgi?id=zsl01000123456&CON_LNG=chi`
    let options = {
        uri: `${x_service.xhost2}${url}`,
        json: true
    }
    let res = await rp(options)
    let res_json = parseXml(res)
    return res_json
}

// 借阅历史
// op=loan_history&bor_id=ID51&bor_id_type=00&user_name=www-x&user_password=xxx

// exports.wd_loanHistory
//测试api
exports.get_wd_News = async (param) => {
    let data = {
        title: '武汉大学第四届3D打印设计大赛”获奖名单的通知'
    }
    // let res = await NewsData.getNewsData(param)
    let res = await NewsData.getNewForTime(param)
    return {
        success: 'ok',
        data: res
    }
}


// 图书借阅排行榜  基于elibapi
exports.billboard = async (param) => {
    let currentWallToken = await wallToken()
    let billboardUrl = `wall/ranking/bibLoan?cirtype=${param.cirtype}&libcode=${param.libcode}&page=${param.page}&size=${param.size}`
    let options = {
        uri: `${cfg.elib.other_url}${billboardUrl}`,
        json: true,
        headers: {
            Authorization: currentWallToken
        }
    }
    let res = await rp(options)
    return res
}

// 设置第三方应用 后台设置api
exports.setServer = async (param) => {
    let otherApp = await OtherApp.setApp(param)
    return otherApp
}

//获取配置的第三方应用
exports.getApps = async (param) => {
    let apps = await OtherApp.getApps()
    return apps
}

//删除某个第三方应用
exports.delApp = async (param) => {
    let res = await OtherApp.delApp(param)
    return res
}

//七牛云相关 图片文件存储
const qiniu = require('qiniu')

//上传token获取
exports.uploadToken = async () => {
    console.log('上传token获取')
    let opt = {
        name: 'qiniu'
    }
    let x_service = await Cfg.get_param_info(opt)
    console.log(x_service)
    // 创建上传凭证
    const accessKey = 'XRBeBiGUGzPprMKz1B-DKP76a5iwuy20ykzHxybq' //x_service.accessKey
    const secretKey = 'oY7Mk66R8S9NiuitgNSOMaYAaZC88L1awtUzza1x' //x_service.secretKey
    // XRBeBiGUGzPprMKz1B-DKP76a5iwuy20ykzHxybq
    // oY7Mk66R8S9NiuitgNSOMaYAaZC88L1awtUzza1x
    const mac = new qiniu.auth.digest.Mac(accessKey, secretKey)

    let token = await QINIU.getUploadToken()
    if (token) {
        const now = new Date().getTime()
        let expiresIn = token.expires_in
        console.log('已存在token')
        console.log(now)
        console.log(expiresIn)
        if (now < expiresIn) {
            console.log('token 有效  直接返回')
            return token.token
        } else {
            console.log('token 无效  重新拉起')
            let options = {
                scope: 'sh-rfid',
                expires: 7200
            }
            let putPolicy = new qiniu.rs.PutPolicy(options)
            let uploadToken = putPolicy.uploadToken(mac)
            //存储到库
            const expiresIn = now + (options.expires - 20) * 1000
            let token_data = {
                uploadtoken: uploadToken,
                expires_in: expiresIn
            }
            await QINIU.saveUploadToken(token_data)
            return uploadToken
        }
    } else {
        console.log('不存在token')

        let options = {
            scope: x_service.bucket,
            expires: 7200
        }
        let putPolicy = new qiniu.rs.PutPolicy(options)
        let uploadToken = putPolicy.uploadToken(mac)
        //存储到库
        const now = new Date().getTime()
        const expiresIn = now + (options.expires - 20) * 1000
        let token_data = {
            uploadtoken: uploadToken,
            expires_in: expiresIn
        }
        await QINIU.saveUploadToken(token_data)
        return uploadToken
    }
}

//设置轮播图
exports.setCarousel = async (param) => {
    let res = await Carousel.setCarousel(param)
    return res
}

exports.NewSetCarousel = async (params) => {
    let del_res = await Carousel.delCarousel()
    console.log(del_res)
    console.log(params)
    try {
        for (let i = 0; i < params.length; i++) {
            let res = await Carousel.setCarousel(params[i])
            console.log(res)
        }
        return {
            code: 1,
            msg: 'is ok'
        }

    } catch (error) {
        return {
            code: 0,
            msg: 'is failed'
        }
    }


}

exports.delCarousel = async (param) => {
    let res = await Carousel.delCarousel(param)
    return res
}
exports.getCarousel = async () => {
    let res = await Carousel.getCarousel()
    return res
}

//本地存储图片
exports.uploadfile = async (param) => {

    let files = param
    console.log(files)
    if (Array.isArray(files.image)) {
        let urls = []
        let urls2 = []
        for (let i = 0; i < files.image.length; i++) {
            console.log(JSON.stringify(files.image[i]['path']))
            // 创建可读流
            const reader = fs.createReadStream(files.image[i]);
            let filePath = path.join(__dirname, '../../public/img') + `/${ files.image[i]['name']}`;
            let remotefilePath = `http://localhost/img` + `/${ files.image[i]['name']}`;
            // 创建可写流
            const upStream = fs.createWriteStream(filePath);
            // 可读流通过管道写入可写流
            reader.pipe(upStream);
            urls.push(remotefilePath)
            let item = {
                imgurl: remotefilePath
            }
            let res2 = await Carousel.setCarousel(item)
            urls2.push(res2)
        }
        return {
            success: 'ok',
            url: urls,
            result: urls2
        }
    } else {
        //('不是个数组  ')

        // 创建可读流
        const reader = fs.createReadStream(files['image']['path']);
        let filePath = path.join(__dirname, '../../public/img') + `/${ files['image']['name']}`;
        let remotefilePath = `http://localhost/img` + `/${ files['image']['name']}`;
        // 创建可写流
        const upStream = fs.createWriteStream(filePath);
        // 可读流通过管道写入可写流
        reader.pipe(upStream);
        let item = {
            imgurl: remotefilePath
        }
        let res2 = await Carousel.setCarousel(item)

        return {
            url: remotefilePath,
            result: res2
        }
    }



}

// 小程序相关
exports.wxlogin = async (params) => {
    let appid = config.wechatapp.AppID
    let appsecret = config.wechatapp.AppSecret
    let baseurl = `https://api.weixin.qq.com/sns/jscode2session`
    let options = {
        uri: `${baseurl}?appid=${appid}&secret=${appsecret}&js_code=${params.code}&grant_type=authorization_code`,
        json: true
    }
    let res = await rp(options)
    let openid = res.openid
    return res
}


// 2020 新增接口需求

exports.wd_loan = async (params) => {
    console.log(params)
    console.log('手机借书')
    //借书 四个参数
    //BOR_ID 读者id 、barcode 单册条码、staff_id 工作人员账号 、station-id 工作站ID 
    let opt = {
        name: 'wdelib'
    }
    // let station_id = ['GXG', 'WLG', 'XXG', 'YXG', 'WLC'] //工作站id、
    let x_service = await Cfg.get_param_info(opt)

    // 
    let openid = params.openid
    let wd_boy = await WdBoy.findOne({
        openid: openid
    })
    console.log(wd_boy)
    let wd_id = wd_boy.wd_id || wd_boy.bor_id

    // 

    // 循环 站点id 直到可借书为止
    let initurl = `?op=lcl_loan&bor_id=${params.bor_id || wd_id}&barcode=${params.barcode}&staff_id=${x_service.user_name}&user_name=${x_service.user_name}&user_password=${x_service.user_password}&CON_LNG=chi`


    // 特定 借书工作站
    let uni_station = 'MOBILE'
    let url = `${initurl}&STATION-ID=${uni_station}`
    let options = {
        uri: `${x_service.xhost}${url}`,
        json: true
    }
    console.log(options.uri)
    let res = await rp(options)
    let resJson = parseXml(res);

    if (!resJson['lcl-loan'].error) {
        return {
            code: 1,
            wd_boy,
            barcode: params.barcode,
            result: resJson['lcl-loan'].z13['z13-title']
        }
    } else if (resJson['lcl-loan'].error) {
        return {
            code: 0,
            result: resJson['lcl-loan'].error,
            wd_boy,
            barcode: params.barcode
        }
    }

    return {
        code: 0,
        result: '未知错误,请重新扫码',
        wd_boy,
        barcode: params.barcode
    }
}