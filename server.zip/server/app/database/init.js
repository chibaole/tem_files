/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-20 01:05:55
 * @Description: file content
 */

const mongoose = require('mongoose')
const { resolve } = require('path')
const glob = require('glob')
mongoose.Promise = global.Promise


exports.initSchemas = () => {
  glob.sync(resolve(__dirname, './schema', '**/*.js')).forEach(require)
}
// --
exports.connect = (db) => {
  let maxConnectTimes = 0
  return new Promise(resolve => {
    mongoose.connect(db, { useNewUrlParser: true ,useUnifiedTopology: true })
    mongoose.connection.on('disconnect', () => {
      maxConnectTimes++

      if (maxConnectTimes < 5) {
        mongoose.connect(db,{ useNewUrlParser: true ,useUnifiedTopology: true })
      } else {
        throw new Error('数据库挂了')
      }
    })
    mongoose.connection.on('error', err => {
      maxConnectTimes++
      //(err)

      if (maxConnectTimes < 5) {
        mongoose.connect(db,{ useNewUrlParser: true ,useUnifiedTopology: true })
      } else {
        throw new Error('数据库挂了')
      }
    })
    mongoose.connection.on('open', () => {
      resolve()
      
    })
  })
}
