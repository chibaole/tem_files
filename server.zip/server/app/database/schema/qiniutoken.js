/*
 * @Author: 刘攀
 * @Date: 2019-11-27 13:54:18
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:31:07
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const QINIUSchema = new Schema({
  name: String, // uploadtoken
  token: String,
  expires_in: Number,
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})

QINIUSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

QINIUSchema.statics = {
  async getUploadToken() {
    const token = await this.findOne({
      name: 'uploadtoken'
    })

    if (token && token.token) {
      token.uploadtoken = token.token
    }

    return token
  },

  async saveUploadToken(data) {
    let token = await this.findOne({
      name: 'uploadtoken'
    })

    if (token) {
      token.token = data.uploadtoken
      token.expires_in = data.expires_in
    } else {
      token = new QINIU({
        name: 'uploadtoken',
        token: data.uploadtoken,
        expires_in: data.expires_in
      })
    }

    await token.save()

    return data
  }
}

const QINIU = mongoose.model('QINIU', QINIUSchema)