// {type,title,link,time}
// 爬取图书馆公告的数据
/*
 * @Author: 刘攀
 * @Date: 2019-11-26 16:46:24
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:32:51
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const WDnoticeSchema = new Schema({
    type: String,
    title: String,
    link: String,
    time: String,
    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

WDnoticeSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

WDnoticeSchema.statics = {
    async getNews() {
        let news = await this.find()
        if (news) {
            return news
        } else {
            return {
                status: false
            }
        }

    },

    async setNews(data) {
        let news = this.findOne({
            'link': data.link
        })
        if (!news) {
            let news = new WDnotice({
                type: data.type,
                title: data.title,
                link: data.link,
                time: data.time
            })
            await news.save()

        }
        return news

    },
    async delNews(param) {

        let res = await this.remove({}, function (err) {
            return err
        });
        return res

    }
}

const WDnotice = mongoose.model('WDnotice', WDnoticeSchema)