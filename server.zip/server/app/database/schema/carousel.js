/*
 * @Author: 刘攀
 * @Date: 2019-11-26 16:46:24
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-04-29 17:01:42
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const CarouselSchema = new Schema({
    name: String,
    imgurl: String,
    title:String,
    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

CarouselSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = this.meta.updatedAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }

    next()
})

CarouselSchema.statics = {
    async getCarousel() {
        let carousel = await this.find()
        if (carousel) {
            return carousel
        } else {
            return {
                status: false
            }
        }

    },

    async setCarousel(data) {    
        let  carousel = new Carousel({
            name: data.name,
            imgurl: data.imgurl,
            title:'轮播图'
        })
        await carousel.save()
        return carousel
        
    },
    async delCarousel() {

        let res = await this.deleteMany({});
        return res

    }
}

const Carousel = mongoose.model('Carousel', CarouselSchema)