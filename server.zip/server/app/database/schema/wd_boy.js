/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:31:56
 * @Description: file content
 */
const mongoose = require('mongoose')

const Schema = mongoose.Schema

const WdBoySchema = new Schema({
  openid: String,
  unionid: String,
  nickname: String,
  address: String,
  province: String,
  country: String,
  city: String,
  gender: String,
  avatar: String,

  bor_id: String,
  qr_borid: String,
  wd_id: String,
  status: String,
  library: String,
  from: String,
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})

// 中间件
WdBoySchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

mongoose.model('WdBoy', WdBoySchema)