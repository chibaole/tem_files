/*
 * @Author: 刘攀
 * @Date: 2019-11-15 11:23:14
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-20 00:09:18
 * @Description: file content
 */
const mongoose = require('mongoose')
const Schema = mongoose.Schema

const ConfigSchema = new Schema({
    name: String,
    title: String,
    redirect_uri: String,
    // 公众号
    wechat: {
        appID: String,
        appSecret: String,
        token: String,
        mch_id: String,
        key: String,
        redirect_uri: String,

    },
    // elib部分

    elib: {
        account: String,
        password: String,
        client_id: String,
        baseurl: String,
        other_url: String,
        autordrno: String,
        rdrtype: String
    },
    wdelib: {
        xhost: String,
        xhost2: String,
        user_name: String,
        user_password: String,
        library: String,
        base: String

    },
    qiniu: {
        accessKey: String,
        secretKey: String,
        domain: String,
        qiniuaddr: String,
        bucket: String

    },
    meta: {
        createdAt: {
            type: Date,
            default: Date.now()
        },
        updatedAt: {
            type: Date,
            default: Date.now()
        }
    }
})

ConfigSchema.pre('save', function (next) {
    if (this.isNew) {
        this.meta.createdAt = this.meta.updatedAt = Date.now()
    } else {
        this.meta.updatedAt = Date.now()
    }
    next()
})

ConfigSchema.statics = {
    async getConfig() {
        let config = await this.findOne({
            name: 'config'
        })
        if (!config) {
            config = {}
        }
        return config
    },
    async setConfig(param) {
        let config = await this.findOne({
            name: 'config'
        })
        if (config) {
            config.title = param.title,
                config.redirect_uri = param.redirect_uri,
                config.wechat = {
                    appID: param.appID,
                    appSecret: param.appSecret,
                    token: param.token,
                    mch_id: param.mch_id,
                    key: param.key,
                    redirect_uri: param.redirect_uri,

                }
            config.elib = {
                account: param.elib_account,
                password: param.elib_password,
                client_id: param.elib_client_id,
                baseurl: param.elib_baseurl,
                other_url: param.other_url,
                autordrno: param.autordrno,
                rdrtype: param.rdrtype
            }

        } else {
            config = new Config({
                name: 'config',
                title: param.title || '',
                redirect_uri: param.redirect_uri || '',
                wechat: {
                    appID: param.appID,
                    appSecret: param.appSecret,
                    token: param.token,
                    mch_id: param.mch_id,
                    key: param.key,
                    redirect_uri: param.redirect_uri || ''
                },
                elib: {
                    account: param.elib_account,
                    password: param.elib_password,
                    client_id: param.elib_client_id,
                    baseurl: param.elib_baseurl,
                    other_url: param.other_url,
                    autordrno: param.autordrno,
                    rdrtype: param.rdrtype
                }
            })
        }
        await config.save()
        return config
    },
    async getAppid() {
        const config = await this.findOne({
            name: 'config'
        })
        if (config && config.wechat.appID) {
            config.wechat.appID = config.wechat.appID
        }
        return config.wechat.appID
    },
    async getAppSecret() {
        const config = await this.findOne({
            name: 'config'
        })
        if (config && config.wechat.appSecret) {
            config.wechat.appSecret = config.wechat.appSecret
        }
        return config.wechat.appSecret
    },
    async getToken() {
        const config = await this.findOne({
            name: 'config'
        })

        if (config && config.wechat.token) {
            config.wechat.token = config.wechat.token
        }
        return config.wechat.token
    },
    // 新的配置形式

    async get_param_info(param) {
        let item_name = param.name
        // //(item_name)
        let config = await this.findOne({
            name: 'config'
        })
        if (config) {
            let info_data = config[item_name]
            // //(info_data)
            return info_data
        }
    },
    async set_param_info(param) {
        let config = await this.findOne({
            name: 'config'
        })
        console.log(config)
        let item_name = param.name
        console.log(item_name)
        //查找
        if (config) {
            if (item_name === 'wechat') {
                config[item_name] = {
                    appID: param.appID,
                    appSecret: param.appSecret,
                    token: param.token,
                    mch_id: param.mch_id,
                    key: param.key,
                    redirect_uri: param.redirect_uri

                }
            } else if (item_name === 'wdelib') {
                config[item_name] = {
                    xhost: param.xhost,
                    xhost2: param.xhost2,
                    user_name: param.user_name,
                    user_password: param.user_password,
                    library: param.library,
                    base: param.base
                }
            } else if (item_name === 'qiniu') {
                config[item_name] = {
                    accessKey: param.accessKey,
                    secretKey: param.secretKey,
                    domain: param.domain,
                    qiniuaddr: param.qiniuaddr,
                    bucket: param.bucket
                }
            }
        } else {
            if (item_name === 'wechat') {
                config = new Config({
                    name: 'config',
                    item_name: {
                        appID: param.appID,
                        appSecret: param.AppSecret,
                        token: param.Token,
                        mch_id: param.mch_id,
                        key: param.key,
                        redirect_uri: param.redirect_uri,

                    }
                })

            } else if (item_name === 'wdelib') {
                config = new Config({
                    name: 'config',
                    item_name: {
                        xhost: param.xhost,
                        xhost2: param.xhost2,
                        user_name: param.user_name,
                        user_password: param.user_password,
                        library: param.library,
                        base: param.base
                    }
                })
            } else if (item_name === 'qiniu') {
                config = new Config({
                    name: 'config',

                    item_name: {
                        accessKey: param.accessKey,
                        secretKey: param.secretKey,
                        domain: param.domain,
                        qiniuaddr: param.qiniuaddr,
                        bucket: param.bucket
                    }
                })
            }
        }
        await config.save()
        return config[item_name]
    }
}

const Config = mongoose.model('Config', ConfigSchema)

