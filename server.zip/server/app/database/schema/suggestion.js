/*
 * @Author: 刘攀
 * @Date: 2019-10-16 16:36:36
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-12-18 15:31:48
 * @Description: file content
 */
// 1. Schema Comment 设计
// 2. 实现 controller
// 3. 增加对应的路由
// 4. 增加留言的表单以及展现预留回复列表
function dateFormat(fmt, date) {
  console.log(date)
  let ret;
  let opt = {
      "Y+": date.getFullYear().toString(),        // 年
      "m+": (date.getMonth() + 1).toString(),     // 月
      "d+": date.getDate().toString(),            // 日
      "H+": date.getHours().toString(),           // 时
      "M+": date.getMinutes().toString(),         // 分
      "S+": date.getSeconds().toString()          // 秒
      // 有其他格式化字符需求可以继续添加，必须转化成字符串
  };
  for (let k in opt) {
      ret = new RegExp("(" + k + ")").exec(fmt);
      if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
      };
  };
  console.log(fmt)
  return fmt;
}
const mongoose = require('mongoose')
const Schema = mongoose.Schema
const ObjectId = Schema.Types.ObjectId

const SuggestionSchema = new Schema({
  up_author:{
    openid:String,
    nickname:String,
    avatar:String,
    author_id:String
  },
  content: String,
  reply:String,
  meta: {
    createdAt: {
      type: Date,
      default: Date.now() 
      // default: dateFormat('YYYY-mm-dd HH:MM',  new Date(Date.now() + 28800000) )
    },
    updatedAt: {
      type: Date,
      default: Date.now() 

      // default:  dateFormat('YYYY-mm-dd HH:MM',  new Date(Date.now() + 28800000))
    }
  }
})
// let date = new Date()
// dateFormat("YYYY-mm-dd HH:MM", date)
// >>> 2019-06-06 19:45`
SuggestionSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt =       Date.now() 
  } else {
    this.meta.updatedAt =        Date.now() 
  }

  next()
})

const Suggestion = mongoose.model('Suggestion', SuggestionSchema)

