/*
 * @Author: 刘攀
 * @Date: 2019-10-16 16:36:36
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:31:19
 * @Description: file content
 */
// 1. Schema Comment 设计
// 2. 实现 controller
// 3. 增加对应的路由
// 4. 增加留言的表单以及展现预留回复列表

const mongoose = require('mongoose')
const Schema = mongoose.Schema
const SuggestionSchema = new Schema({
  content: String,
  openid: String,
  up_author: {
    openid: String,
    nickname: String,
    avatar: String,
    author_id: String
  },
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})

SuggestionSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

const Suggestion = mongoose.model('Suggestion', SuggestionSchema)