/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-06-28 11:37:57
 * @Description: file content3
 */


const {
  resolve
} = require('path')
const isProd = process.env.NODE_ENV === 'production'

let cfg = {
  port: 3009,
  db: 'mongodb://202.114.65.36:27017/WechatWD',

  // db: 'mongodb://127.0.0.1:27017/WechatWD',
  // db:'mongodb://127.0.0.1:27017/normWechat',

  host: 'http://opactest.lib.whu.edu.cn/X?user_name=RFID_X&user_password=RFID_X&',
  host2: 'http://opactest.lib.whu.edu.cn/cgi-bin/',
  user_name: 'RFID_X',
  user_password: 'RFID_X',
  library: 'whu50',
  base: 'whu01',
  appID: 'wxadf7382f1ae53fb6',
  appsecret: 'fb2d45c8f3ded61b25cd7d4934faece3',
  wechatapp: {
    AppID: 'wxbcfc3d4c0ab04031',
    AppSecret: 'f9213d9bd4e3eda8d01b1ff8ca962c03'
  }
}
if (isProd) {
  const config = require(resolve(__dirname, '../../../../config/config.json'))
  cfg = Object.assign(cfg, config)
}

module.exports = cfg