/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors  : 刘攀
 * @LastEditTime : 2020-01-17 15:51:59
 * @Description: file content
 */

const request = require('request-promise')
const base = 'https://api.weixin.qq.com/sns/'
const api = {
  authorize: 'https://open.weixin.qq.com/connect/oauth2/authorize?',
  accessToken: base + 'oauth2/access_token?',
  userInfo: base + 'userinfo?'
}

module.exports = class WechatOAuth {
  constructor (opts) {
    this.appID = opts.appID
    this.appSecret = opts.appSecret
  }

  async request (options) {
    options = Object.assign({}, options, { json: true })

    try {
      const res = await request(options)
      return res
    } catch (err) {
      //(err)
    }
  }

  // 详细信息/主动授权： snsapi_userinfo
  // 基本信息/静默授权： snsapi_base
  async getAuthorizeURL (scope = 'snsapi_base', target, state) {
    let appID = await this.appID()
    const url = `${api.authorize}appid=${appID}&redirect_uri=${encodeURIComponent(target)}&response_type=code&scope=${scope}&state=${state}#wechat_redirect`
    return url
  }

  async fetchAccessToken (code) {
    let appID = await this.appID()
    let appSecret = await this.appSecret()

    const url = `${api.accessToken}appid=${appID}&secret=${appSecret}&code=${code}&grant_type=authorization_code`
    
    const res = await this.request({ url })

    return res
  }

  async getUserInfo (token, openID, lang = 'zh_CN') {
    const url = `${api.userInfo}access_token=${token}&openid=${openID}&lang=${lang}`
    const res = await this.request({ url })
    return res
  }
}
