/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-21 14:38:04
 * @Description: file content
 */
const Koa = require('koa')
const {
  resolve
} = require('path')
const serve = require('koa-static')
const Router = require('koa-router')
const config = require('./config/config')
const koaBody = require('koa-body');
const {
  initSchemas,
  connect
} = require('./app/database/init')
var cors = require('koa2-cors');;
(async () => {

  await connect(config.db)
  initSchemas()
  const {
    getNewsLoop,
    getNewsEveryday,
    getlastOne,
    getFirstOne
  } = require('./app/api/spider')
  

  //定时模块定时启动抓取数据函数函数
  const schedule = require('node-schedule');
  let rule = new schedule.RecurrenceRule();
  let times = [12, 18];
  rule.hour  = times;
  rule.minute = 50;
  // rule.second = 10;
  schedule.scheduleJob(rule, function () {
    getFirstOne()
    getNewsEveryday();
  });

  // 生成服务器实例
  const app = new Koa()
  app.use(cors());

  const router = new Router()

  app.keys = ['wechat_server']

  app.use(serve(resolve(__dirname, './public')))

  var path = require('path');

  app.use(koaBody({
    // 支持文件格式
    multipart: true,

  }));

  require('./router/index')(router)

  app.use(router.routes()).use(router.allowedMethods())
  app.listen(config.port)
  console.log('Listen: ' + 3009)
})()