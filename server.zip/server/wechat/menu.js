/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-04-17 11:21:32
 * @Description: file content
 */

module.exports = {
  button: [{
      type: "view",
      name: "微信服务大厅",
      url: "http://wd.lpfyy.cn"
    },
    {
      "name": "服务指南",
      "sub_button": [{
        "type": "scancode_waitmsg",
        "name": "扫码借书",
        "key": "scan",
        "sub_button": []
      }]
    }
  ]
}