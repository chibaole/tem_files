/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-11-25 22:18:34
 * @Description: file content
 */
const Wechat = require('../wechat-lib')
const WechatOAuth = require('../wechat-lib/oauth')

const mongoose = require('mongoose')
const conf = mongoose.model('Config')

const Token = mongoose.model('Token')
const Ticket = mongoose.model('Ticket')
let cfg = {}
async function init(){
    cfg = await conf.findOne({
    name: 'config'
})
}
const wechatCfg = {


  wechat: {
    // appID: config.wechat.appID,
    // appSecret: config.wechat.appSecret,
    // token: config.wechat.token,
    token: async () => {
      let res = await conf.getToken()
      return res
    },
    appID: async () => {
      let res = await conf.getAppid()
      return res
    },
    appSecret: async () => {
      let res = await conf.getAppSecret()
      return res
    },
    getAccessToken: async () => {
      const res = await Token.getAccessToken()

      return res
    },
    saveAccessToken: async (data) => {
      const res = await Token.saveAccessToken(data)
      return res
    },
    getTicket: async () => {
      const res = await Ticket.getTicket()

      return res
    },
    saveTicket: async (data) => {
      const res = await Ticket.saveTicket(data)

      return res
    }
  }
}

exports.getWechat = () => new Wechat(wechatCfg.wechat)
exports.getOAuth = () => new WechatOAuth(wechatCfg.wechat)