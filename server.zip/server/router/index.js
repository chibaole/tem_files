/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-05-19 20:13:15
 * @Description: file content
 */



// 
const Wechat = require('../app/controllers/wechat')
const Index = require('../app/controllers/index')
const Elb = require('../app/controllers/elib')
module.exports = router => {
  //  检索图书
  
  router.get('/searchBook', Elb.searchBook)
  // 馆藏检索
  router.get('/listHoldings', Elb.listHoldings)
  //馆藏信息
  router.get('/holding', Elb.holding)

  // 文献借阅排行榜
  router.get('/Billboard',Elb.billboard)

//图书封面查询

router.get('/getCoverImage',Elb.getCoverImage)
  // 建议留言

  router.post('/suggestion',Elb.suggestion)

  router.get('/getSuggestion',Elb.getSuggestion)
  //首页
  router.get('/', Index.homePage)
  //微信消息中间件
  router.get('/sdk', Wechat.sdk)

  // 微信SDK
  router.get('/wechat/getConfig',Wechat.getTicket)

  // 微信 重定向的url、携带code
  router.get('/wechat/getCodeURL',Wechat.oauth)

  //新的微信用户信息获取
router.get('/wechat/userBycode',Wechat.getUserInfo )

// 新增网上读者 /网上办证
router.post('/applyID',Elb.applyID)

// 获取二维码
router.post('/getQRcode',Wechat.getQRcode)


// 获取 elib 系统信息
router.get('/systemInfo',Elb.systemInfo)

//获取绑定信息
router.get('/getBindInfo',Elb.getBindInfo)
// 绑定读者证
router.get('/bindWechatID',Elb.bindWechatID)
//解绑
router.get('/unBindInfo',Elb.unBindInfo)
//读者登录验证
router.get('/rdlogin',Elb.rdLogin)
// 读者基本信息 或者id查询
router.get('/rdrid',Elb.getRdrID)
//读者其他信息/数据
router.get('/userOthInfo',Elb.getUserOthInfo)



router.get('/getTemMessage',Wechat.getTemMessage)

// 发送 模版消息
router.post('/sendTemMessage',Wechat.sendTemMessage)
//读者借阅
router.get('/curBorrowInfo',Elb.getUserBorrow)
//获取读者预约
router.get('/Reserve',Elb.reserinfo)

// 读者财经查询
router.get('/payment',Elb.payment)
//财经付款
router.get('/payRes',Elb.payRes)

// 获取集合所有读者信息
router.get('/allUserInfo',Elb.allUserInfo)

//续借
router.get('/renewFn',Elb.renewFn)
//一键续借
router.get('/allrenew',Elb.allRenew)

//图书预约
router.get('/reservation',Elb.reservation)
// 取消预约
router.get('/cancleAppt',Elb.cancleAppt)
  // 进入微信消息中间件ˇ
  router.get('/wx-hear', Wechat.hear)
  router.post('/wx-hear', Wechat.hear)
  router.get('/test',Elb.test)
  // 异步处理网页的签名
  router.get('/wechat/signature', Wechat.getTicket)
  //对外提供ticket
  // router.get('/wx-ticket',Wechat.getTicket)
  //微信支付 配置sdk
router.get('/wx-ticket',Wechat.getSDKSignature)
  // 跳到授权中间服务页面
  router.get('/wx-oauth', Wechat.oauth)
  // 通过 code 获取用户信息
  router.get('/userinfo', Wechat.userinfo)
//获取菜单列表
  router.get('/menulist', Wechat.menuListNew)
  //更新菜单
  router.post('/updateMenu',Wechat.updateMenu)




//payjs 获取open ID
router.get('/payjs_openid',Wechat.getopenIDUrl)


  // router.get('/wx_payjs',Wechat.payjsAPI)
  router.get('/wx_payjs',Wechat.wxPayOrder)
// 微信实名认证

router.get('/realNameAuth',Wechat.realNameAuth)
router.get('/auth_code_url',Wechat.auth_code_url)


  //活动公告
  router.get('/libraryNotice',Elb.libraryNotice)
  // 微信素材
  //获取素材列表
  router.get('/batchMaterial',Wechat.batchMaterial)
// //上传一个素材
router.post('/uploadMaterial',Wechat.uploadMaterial)
//获取某个素材
  // router.get('/batchMaterial',Wechat.batchMaterial)
  router.post('/changePwd',Elb.changePwd)

  // 获取高德地图 poi ID
  router.post('/getAMapID',Elb.getAMapID)

  //检测是否绑定读者账号
   router.get('/testAuth',Elb.testAuth)
   //是否登录 校验
   router.get('/isLogin',Elb.isLogin)

//设置微信公众号相关信息
   router.post('/setConfig',Wechat.setConfig)
   //获取公众号配置信息
   router.get('/fetchConfig',Wechat.fetchConfig)

   //设置 第三方服务

   router.post('/setServer',Elb.setServer)
 
   //获取已配置的 第三方应用
   router.get('/getApps',Elb.getApps)

   router.get('/delApp',Elb.delApp)

   router.post('/uploadfile',Elb.uploadfile)

   router.get('/uploadToken',Elb.uploadToken)

   router.post('/setCarousel',Elb.setCarousel)
   router.get('/delCarousel',Elb.delCarousel)
   router.get('/getCarousel',Elb.getCarousel)

  router.get('/allComment',Elb.allComment)

// wechat app

router.get('/wxlogin',Elb.wxlogin)
}
