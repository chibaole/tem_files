/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-12-02 15:07:31
 * @Description: file content
 */
module.exports = {
  wechat: require('./wechat'),
  elib:require('./elib'),
  wxPay:require('./wechatPay')
}
