/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2018-08-01 11:04:16
 * @Description: file content
 */
const mongoose = require('mongoose')

exports.homePage = async (ctx, next) => {

  // 首页数据


 
}
