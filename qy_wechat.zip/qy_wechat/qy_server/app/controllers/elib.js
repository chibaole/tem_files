/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-07-17 10:18:26
 * @Description: file content
 */
const fs = require('fs')

// 数据库操作
const mongoose = require('mongoose')
const Suggestion = mongoose.model('Suggestion')

// 
const _ = require('lodash')
const api = require('../api')
//根据字段 检索图书
exports.searchBook = async (ctx, next) => {
    console.log('根据字段 检索图书')
 
    // let token = ctx.headers['token']
    let param = ctx.query
    // param['token'] = token
    console.log(param)

    
    const books = await api.elib.searchBookBykeyword(param)
    ctx.body = books

}
//馆藏信息
exports.holding = async (ctx, next) => {
    let param = ctx.query
    console.log(param)

    const res = await api.elib.holding(param)
    ctx.body = res
}
// 馆藏检索
exports.listHoldings = async (ctx, next) => {

    let param = ctx.query
    console.log(param)
    let res = await api.elib.listHoldings(param)

    ctx.body = res
}
// 预约某个馆藏图书
exports.reservation = async (ctx, next) => {
    let param = ctx.query
    const res = await api.elib.reservation(param)
    ctx.body = res

}

//文献借阅榜
exports.billboard = async (ctx, next) => {
 
    let param = ctx.query
    let res = await api.elib.billboard(param)
    ctx.body = res
}
//图书封面

exports.getCoverImage = async (ctx,next)=>{
    let param = ctx.query
    console.log(param)
    let res = await api.elib.getCoverImage(param)
    ctx.body = res
}
//建议 投诉
exports.suggestion = async (ctx, next) => {
    let param = ctx.request.body.data //获取post提交的数据 字符串

    let res = await api.elib.suggestion(param)


    ctx.body = res

}
//查询读者 建议留言

exports.getSuggestion = async(ctx,next)=>{
    let param = ctx.query

    let res = await api.elib.getSuggestion(param)
    ctx.body = res
}

// 办证 新增网上读者
exports.applyID = async (ctx, next) => {
    let postParam = ctx.request.body.data //获取post提交的数据 字符串
    let res = await api.elib.applyID(postParam)
    ctx.body = res
}

// 更新用户信息 增加 读者ID 读者证号
exports.userUpdate = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.updateUser(param)
    ctx.body = res
}
// 获取elib的系统信息

exports.systemInfo = async (ctx, next) => {
    console.log('获取elib的系统信息')

    
    let param = ctx.query
    console.log(param)
    let res = await api.elib.systemInfo(param)
    ctx.body = res
}

//查询绑定信息
exports.getBindInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getBindInfo(param)
    ctx.body = res
}
//绑定读者账号
exports.bindWechatID = async (ctx, next) => {
    let param = ctx.query

    let res = await api.elib.bindWechatID(param)
    ctx.body = res
}
exports.unBindInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.unBindInfo(param)
    ctx.body = res
}
exports.rdLogin = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.rdLogin(param)
    ctx.body = res
}
//根据读者的账号  获取读者id  便于绑定 微信用户
exports.getRdrID = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getRdrID(param)
    ctx.body = res
}
// 预约图书
exports.reservation = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.reservation(param)
    ctx.body = res
}
// 获取读者更多信息
exports.getUserOthInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getUserOthInfo(param)
    ctx.body = res
}

//获取读者当前借阅列表
exports.getUserBorrow = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.getUserBorrow(param)
    ctx.body = res
}

//读者预约信息
exports.reserinfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.reserinfo(param)
    ctx.body = res
}
// getReserve
//用户所有数据
exports.allUserInfo = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.allUserInfo(param)
    ctx.body = res
}
// 续借

exports.renewFn = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.renewFn(param)
    ctx.body = res
}

exports.allRenew = async (ctx, next) => {
    console.log('循环续借操作 controller')

    let param = ctx.query
    console.log(param)
    let res = await api.elib.yyRenewFn(param)
    ctx.body = res
}
// 读者财经信息查询
exports.payment = async (ctx, next) => {
    let param = ctx.query

    let res = await api.elib.payment(param)
    ctx.body = res
}
//财经 付款

exports.payRes = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.payRes(param)
    ctx.body = res
}

//取消预约
exports.cancleAppt = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.cancleAppt(param)
    ctx.body = res
}


exports.libraryNotice = async (ctx, next) => {

    let param = ctx.query || {}
    let res = await api.elib.libraryNotice(param)
    ctx.body = res
}

exports.changePwd = async (ctx, next) => {
    
    let param = ctx.request.body
    console.log(param)
    let res = await api.elib.changePwd(param)
    ctx.body = res
}

exports.getAMapID = async (ctx, next) => {
    let param = ctx.request.body
    console.log(param)
    let res = await api.elib.getAMapID(param)
    ctx.body = res
}

exports.testAuth = async (ctx, next) => {
    console.log('检测用户绑定')
    let param = ctx.query
    console.log(param)
    let res = await api.elib.testAuth(param)
    ctx.body = res
}

exports.isLogin = async (ctx, next) => {
    let param = ctx.query

    let res = await api.elib.isLogin(param)
    console.log(res)
    ctx.body = res
}

exports.setServer = async (ctx, next) => {
    let param = ctx.request.body
    let res = await api.elib.setServer(param)

    ctx.body = res
}

exports.getApps = async (ctx, next) => {
    let res = await api.elib.getApps()
    ctx.body = res
}

exports.delApp = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.delApp(param)
    ctx.body = res
}
exports.uploadfile = async (ctx, next) => {
    console.log('上传文件')
    const file = ctx.request.files || ctx.request.body.files || ctx.request.body; // 获取上传文件
    console.log(file)
    // 创建可读流
    const reader = fs.createReadStream(file.path);
    let filePath = path.join(__dirname, 'public/upload/') + `/${file.name}`;
    // 创建可写流
    const upStream = fs.createWriteStream(filePath);
    // 可读流通过管道写入可写流
    reader.pipe(upStream);

}
exports.uploadToken = async (ctx, next) => {
    let token = await api.elib.uploadToken()
    ctx.body = token
}

exports.setCarousel = async (ctx, next) => {
    console.log('存储轮播图')
    let param = ctx.request.body
    console.log(param)
    let res = await api.elib.setCarousel(param)
    ctx.body = res
}
exports.delCarousel = async (ctx, next) => {
    let param = ctx.query
    let res = await api.elib.delCarousel(param)
    ctx.body = res
}
exports.getCarousel = async (ctx, next) => {
    let res = await api.elib.getCarousel()
    ctx.body = res
}

exports.allComment = async (ctx,next)=>{
    let res = await api.elib.allComment()
    ctx.body  = res
}
// wechat app

exports.wxlogin = async (ctx, next) => {
    let params = ctx.query
    let res = await api.elib.wxlogin(params)
    ctx.body = res
}


exports.test = async (ctx,next) =>{
    console.log('test')
    const Userinfo = mongoose.model('Config')
    // let obj = await Userinfo.findOne({'nickname':'刘攀'})
    let elibuser = await Userinfo.findOne({
        name: 'config'
    })
    console.log(elibuser.wechat)
    let res = elibuser.wechat
    console.log(res.appID)

    ctx.body = res
}
exports.getToken  = async(ctx,next) => {
   

    let res = await api.elib.getToken()
    ctx.body = res
}