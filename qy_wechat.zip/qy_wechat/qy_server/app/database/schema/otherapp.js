/*
 * @Author: 刘攀
 * @Date: 2019-11-22 13:58:29
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-11-26 15:20:19
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const AppSchema = new Schema({
  name: String, 
  url:String,
  icon:String,
  to:String,
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})

AppSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

AppSchema.statics = {
  async getApps () {
    let  apps = await this.find({})

    if (apps) {
        return apps
    }else{
        return{
            status:false
        }
    }

  },

  async setApp(data) {
    
      let  app = await this.findOne({
            name: data.name
          })
    
   
    if (app) {
        app.url = data.url
        app.icon = data.icon
        app.to = data.to
    } else {
      app = new App({
        name: data.name,
        url: data.url,
        icon: data.icon,
        to:data.to
      })
    }

    await app.save()

    return app
  },
  async delApp(param){

   console.log(param)
   let res =  await  this.remove({ _id: param.id }, function (err) {
       return err
   });
   return res

  }
}

const App = mongoose.model('OtherApp', AppSchema)
