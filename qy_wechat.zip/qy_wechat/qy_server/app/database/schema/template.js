/*
 * @Author: 刘攀
 * @Date: 2019-10-30 13:37:46
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-11-20 17:46:55
 * @Description: file content
 */

const mongoose = require('mongoose')
const Schema = mongoose.Schema

const TemSchema = new Schema({
  title: String, 
  template_id: String,
  type: String,
  data: {},
  meta: {
    createdAt: {
      type: Date,
      default: Date.now()
    },
    updatedAt: {
      type: Date,
      default: Date.now()
    }
  }
})

TemSchema.pre('save', function (next) {
  if (this.isNew) {
    this.meta.createdAt = this.meta.updatedAt = Date.now()
  } else {
    this.meta.updatedAt = Date.now()
  }

  next()
})

TemSchema.statics = {

}

const Temp = mongoose.model('Temp', TemSchema)
