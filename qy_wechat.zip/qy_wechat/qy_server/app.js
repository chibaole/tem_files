/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-07-13 13:42:44
 * @Description: file content
 */
// const Koa = require('koa')
// const { resolve } = require('path')
// const bodyParser = require('koa-bodyparser')
// const serve = require('koa-static')
// const Router = require('koa-router')
// const config = require('./config/config')


// const { initSchemas, connect } = require('./app/database/init')


// ;(async () => {

//   await connect(config.db)

//   initSchemas()
//   // 生成服务器实例
//   const router = new Router()
//   const views = require('koa-views')
// // 跨域设置
// var app = new Koa();
// const cors = require('koa2-cors');// CORS是一个W3C标准，全称是"跨域资源共享"
// app.use(cors()); //全部允许跨域
// // 
//   app.keys = ['wechat_server']
//   app.use(bodyParser())
//   app.use(serve(resolve(__dirname, '../public')))

//   require('./router/index')(router)

//   app.use(router.routes()).use(router.allowedMethods())

//   app.listen(3008)
//   console.log('Listen: ' + 3008)
// })()
const Koa = require('koa')
const {
  resolve
} = require('path')
const serve = require('koa-static')
const Router = require('koa-router')
const config = require('./config/config')
const koaBody = require('koa-body');
const {
  initSchemas,
  connect
} = require('./app/database/init')
var cors = require('koa2-cors');
(async () => {

  await connect(config.db)
  initSchemas()
 


  // 生成服务器实例
  const app = new Koa()
  const router = new Router()

  app.keys = ['wechat_server']

  app.use(serve(resolve(__dirname, './public')))
  app.use(cors());

  var path = require('path');

  app.use(koaBody({
    // 支持文件格式
    multipart: true,

  }));

  require('./router/index')(router)

  app.use(router.routes()).use(router.allowedMethods())
  app.listen(config.port)
  console.log('Listen: ' + config.port)
})()


