/*
 * @Author: 刘攀
 * @Date: 2018-08-01 11:04:16
 * @LastEditors: 刘攀
 * @LastEditTime: 2020-07-21 14:08:18
 * @Description: file content3
 */


const { resolve } = require('path')
const isProd = process.env.NODE_ENV === 'production'

let cfg = {
  port: 3018,
  // db:'mongodb://118.24.121.92:27017/normWechat',
    // db:'mongodb://39.107.85.221:27017/normWechat',
    db:'mongodb://127.0.0.1:27017/normWechat',


  wechatapp:{
    AppID:'wxbcfc3d4c0ab04031',
    AppSecret:'f9213d9bd4e3eda8d01b1ff8ca962c03'
  }

}

if (isProd) {
  const config = require(resolve(__dirname, '../../../../config/config.json'))
  cfg = Object.assign(cfg, config)
}

module.exports = cfg


