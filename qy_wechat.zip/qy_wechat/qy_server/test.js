/*
 * @Author: 刘攀
 * @Date: 2019-11-21 10:16:51
 * @LastEditors: 刘攀
 * @LastEditTime: 2019-11-21 10:19:03
 * @Description: file content
 */
let a = {
    sum:1
}

let b = {
    key:'12'
}

let c = Object.assign(a,b)
console.log(c)